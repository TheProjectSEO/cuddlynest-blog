# Data Flow Diagram: Interview Questions Fix

## Before Fix (BROKEN)

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CSV FILE                                     │
│                                                                      │
│  job_title,section_1_id,section_1_title,section_1_questions_json   │
│  Marketing Manager,general,General Questions,[{"question":"..."..   │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│              class-csv-uploader.php                                  │
│                                                                      │
│  • Reads CSV with fgetcsv()                                         │
│  • Creates associative array from headers + rows                    │
│  • Returns: $row['section_1_questions_json'] = "[{json}...]"       │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│            class-bulk-processor.php                                  │
│                                                                      │
│  STORES THIS STRUCTURE:                                             │
│  $content_data = [                                                  │
│      "section_1" => [                    ← NESTED ARRAY            │
│          "id" => "general",                                         │
│          "title" => "General Questions",                            │
│          "questions" => [                ← ALREADY PARSED ARRAY    │
│              ["question" => "...", "what_to_listen_for" => [...]],  │
│              ["question" => "...", "what_to_listen_for" => [...]]   │
│          ]                                                          │
│      ]                                                              │
│  ]                                                                  │
│                                                                      │
│  Stores as: wp_json_encode($content_data)                          │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   WORDPRESS POST META                                │
│                                                                      │
│  _x0pa_content_json = {                                             │
│      "section_1": {                                                 │
│          "id": "general",                                           │
│          "title": "General Questions",                              │
│          "questions": [{"question":"..."}]                          │
│      }                                                              │
│  }                                                                  │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│        wordpress-interview-questions.php (OLD - BROKEN)              │
│                                                                      │
│  TRYING TO ACCESS WRONG KEYS:                                       │
│  $section_id = $content_data["section_1_id"]  ← ❌ DOESN'T EXIST  │
│  $section_title = $content_data["section_1_title"] ← ❌ NOT FOUND │
│  $questions_json = $content_data["section_1_questions_json"] ← ❌  │
│                                                                      │
│  RESULT: All variables are empty, no content renders               │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
                    ┌─────────┐
                    │ PAGE    │
                    │ SHOWS:  │
                    │ 0 Questions │
                    └─────────┘
```

## After Fix (WORKING)

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CSV FILE                                     │
│                                                                      │
│  job_title,section_1_id,section_1_title,section_1_questions_json   │
│  Marketing Manager,general,General Questions,[{"question":"..."..   │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│              class-csv-uploader.php                                  │
│                                                                      │
│  • Reads CSV with fgetcsv()                                         │
│  • Creates associative array from headers + rows                    │
│  • Returns: $row['section_1_questions_json'] = "[{json}...]"       │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│        class-bulk-processor.php (ENHANCED)                           │
│                                                                      │
│  DEBUG LOGGING ADDED:                                               │
│  ✅ Logs: "Processing row 2: Marketing Manager"                    │
│  ✅ Logs: "Section 1 raw JSON: [{...}]"                            │
│                                                                      │
│  PARSING:                                                           │
│  $questions_json = trim($row["section_1_questions_json"]);         │
│  $questions_json = str_replace("\xEF\xBB\xBF", '', $questions_json);│
│  $questions = json_decode($questions_json, true);                  │
│                                                                      │
│  ✅ Logs: "Successfully parsed 29 questions"                       │
│                                                                      │
│  BUILDS DATA STRUCTURE:                                            │
│  $content_data["section_1"] = [                                     │
│      "id" => "general",                                             │
│      "title" => "General Questions",                                │
│      "questions" => $questions  ← ARRAY, NOT JSON STRING           │
│  ];                                                                 │
│                                                                      │
│  ✅ Logs: "Created content data with 3 sections"                   │
│  ✅ Logs: "Content JSON length: 15234"                             │
│                                                                      │
│  Stores as: wp_json_encode($content_data)                          │
│                                                                      │
│  ✅ Verifies: Stored JSON decodes successfully                     │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   WORDPRESS POST META                                │
│                                                                      │
│  _x0pa_content_json = {                                             │
│      "section_1": {                                                 │
│          "id": "general",                                           │
│          "title": "General Questions",                              │
│          "questions": [                                             │
│              {"question": "Tell me about...", "what_to_listen_...}, │
│              {"question": "What is your...", "what_to_listen_...},  │
│              ... (29 total)                                         │
│          ]                                                          │
│      },                                                             │
│      "section_2": { ... },                                          │
│      "section_3": { ... }                                           │
│  }                                                                  │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────────────┐
│      wordpress-interview-questions.php (FIXED)                       │
│                                                                      │
│  RETRIEVES DATA:                                                    │
│  $content_json = get_post_meta($post->ID, '_x0pa_content_json');   │
│  $content_data = json_decode($content_json, true);                 │
│                                                                      │
│  ✅ Logs: "Post ID: 123"                                           │
│  ✅ Logs: "Job Title: Marketing Manager"                           │
│  ✅ Logs: "JSON Decode Error: No error"                            │
│  ✅ Logs: "Content Data Keys: section_1, section_2, section_3"     │
│                                                                      │
│  ACCESSES NESTED STRUCTURE CORRECTLY:                              │
│  for ($i = 1; $i <= 3; $i++) {                                     │
│      $section_key = "section_{$i}";                                 │
│      if (!isset($content_data[$section_key])) continue;            │
│                                                                      │
│      $section = $content_data[$section_key];  ← ✅ GET ARRAY       │
│      $section_id = $section['id'];            ← ✅ ACCESS NESTED   │
│      $section_title = $section['title'];      ← ✅ ACCESS NESTED   │
│      $questions = $section['questions'];      ← ✅ ALREADY ARRAY   │
│                                                                      │
│      ✅ Logs: "Rendering section 1 with 29 questions"              │
│                                                                      │
│      foreach ($questions as $q) {                                   │
│          // Render question HTML                                    │
│          <h3><?php echo $q['question']; ?></h3>                     │
│          // Render "What to Listen For" box                         │
│      }                                                              │
│  }                                                                  │
└────────────────────────┬─────────────────────────────────────────────┘
                         │
                         ▼
                    ┌─────────┐
                    │ PAGE    │
                    │ SHOWS:  │
                    │ 29 Marketing Manager │
                    │ Interview Questions  │
                    │                      │
                    │ ✅ Section 1: 29 Q's│
                    │ ✅ Section 2: 15 Q's│
                    │ ✅ Section 3: 8 Q's │
                    └─────────┘
```

## Key Differences

### Data Access Pattern

**BEFORE (BROKEN):**
```php
// Trying to access flat keys
$content_data["section_1_id"]              // ❌
$content_data["section_1_title"]           // ❌
$content_data["section_1_questions_json"]  // ❌

// These keys don't exist in the stored data!
```

**AFTER (FIXED):**
```php
// Access nested array structure
$section = $content_data["section_1"];     // ✅ Get section array
$section_id = $section['id'];              // ✅ Access nested id
$section_title = $section['title'];        // ✅ Access nested title
$questions = $section['questions'];        // ✅ Access nested questions array
```

### Data Storage Structure

**WHAT'S ACTUALLY STORED:**
```json
{
    "section_1": {
        "id": "general-questions",
        "title": "General Questions",
        "questions": [
            {
                "question": "Tell me about your experience...",
                "what_to_listen_for": [
                    "Specific campaigns",
                    "Measurable results"
                ]
            },
            {
                "question": "What is your approach to...",
                "what_to_listen_for": [
                    "Strategic thinking",
                    "Data-driven decisions"
                ]
            }
        ]
    },
    "section_2": { ... },
    "section_3": { ... }
}
```

**NOT THIS (what template was looking for):**
```json
{
    "section_1_id": "general-questions",
    "section_1_title": "General Questions",
    "section_1_questions_json": "[{...}]"
}
```

## Debug Flow

```
┌───────────────────────────────────────────────────────────────┐
│                    UPLOAD CSV FILE                             │
└─────────────────────────┬──────────────────────────────────────┘
                          │
                          ▼
              ┌───────────────────────┐
              │ WP_DEBUG Enabled?     │
              └────┬──────────────┬───┘
                   │ YES          │ NO
                   │              │
                   ▼              ▼
         ┌─────────────────┐    Silent
         │  LOGS TO        │    Processing
         │  debug.log:     │
         │                 │
         │ ✅ Row parsed   │
         │ ✅ JSON decoded │
         │ ✅ Questions #  │
         │ ✅ Post created │
         │ ✅ Data stored  │
         └──────┬──────────┘
                │
                ▼
    ┌──────────────────────────┐
    │   Visit Page              │
    └─────────┬─────────────────┘
              │
              ▼
    ┌─────────────────────────┐
    │ WP_DEBUG Enabled?       │
    └────┬──────────────┬─────┘
         │ YES          │ NO
         │              │
         ▼              ▼
┌──────────────────┐  Normal
│  LOGS TO         │  Rendering
│  debug.log:      │
│                  │
│ ✅ Post ID       │
│ ✅ JSON decoded  │
│ ✅ Keys found    │
│ ✅ Sections #    │
│ ✅ Questions #   │
└────────┬─────────┘
         │
         ▼
    ┌────────────────────────┐
    │ PAGE DISPLAYS          │
    │ ✅ Correct count       │
    │ ✅ All questions       │
    │ ✅ All sections        │
    └────────────────────────┘
```

## Troubleshooting Decision Tree

```
                    ┌─────────────────────┐
                    │ Questions showing?  │
                    └──────┬──────────────┘
                           │
                  ┌────────┴────────┐
                  │ YES             │ NO
                  │                 │
                  ▼                 ▼
            ┌─────────┐      ┌──────────────────┐
            │ SUCCESS │      │ Re-upload CSV?   │
            └─────────┘      └──────┬───────────┘
                                    │
                           ┌────────┴────────┐
                           │ YES             │ NO
                           │                 │
                           ▼                 ▼
                    ┌──────────────┐  ┌───────────────────┐
                    │ Still broken?│  │ Enable WP_DEBUG   │
                    └──────┬───────┘  │ Re-upload CSV     │
                           │          └─────────┬─────────┘
                  ┌────────┴────────┐           │
                  │ YES             │ NO        │
                  │                 │           │
                  ▼                 ▼           ▼
         ┌─────────────────┐  ┌─────────┐  ┌──────────────┐
         │ Check debug.log │  │ SUCCESS │  │ Check logs   │
         └────────┬────────┘  └─────────┘  └──────┬───────┘
                  │                                │
                  ▼                                ▼
         ┌──────────────────┐           ┌──────────────────┐
         │ JSON errors?     │           │ Errors found?    │
         └────┬───────┬─────┘           └───┬──────────┬───┘
              │ YES   │ NO                  │ YES      │ NO
              │       │                     │          │
              ▼       ▼                     ▼          ▼
    ┌─────────────┐ ┌──────────────┐  ┌────────┐  ┌─────────┐
    │ Fix CSV     │ │ Run debug    │  │ Fix    │  │ SUCCESS │
    │ JSON format │ │ script       │  │ errors │  └─────────┘
    └─────────────┘ └──────────────┘  └────────┘
```

## Visual Comparison

### BEFORE FIX (Broken Access Pattern)

```
CSV → Bulk Processor → POST META → Template
                                     ↓
                              Tries to access:
                              ❌ section_1_id
                              ❌ section_1_title
                              ❌ section_1_questions_json
                                     ↓
                              Keys don't exist!
                                     ↓
                              Variables are empty
                                     ↓
                              No content renders
                                     ↓
                              "0 Questions" displayed
```

### AFTER FIX (Correct Access Pattern)

```
CSV → Bulk Processor → POST META → Template
                                     ↓
                              Accesses:
                              ✅ $content_data["section_1"]
                                     ↓
                              Gets section array
                                     ↓
                              ✅ $section['id']
                              ✅ $section['title']
                              ✅ $section['questions']
                                     ↓
                              All data retrieved
                                     ↓
                              Content renders
                                     ↓
                              "29 Questions" displayed
```

---

## Summary

The fix was simple but critical:

1. **Identified** that stored data uses nested arrays (`section_1 → {id, title, questions}`)
2. **Changed** template to access nested structure correctly
3. **Added** comprehensive logging to prevent future issues
4. **Verified** data flow from CSV to display

The data was always being stored correctly - the template just wasn't accessing it properly!
