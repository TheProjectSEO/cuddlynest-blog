# Interview Questions Display Fix

## Problem Summary

The interview questions page was showing "0 Marketing Manager Interview Questions" even after uploading the CSV file with content. The questions were not rendering on the page.

## Root Cause

**Data Structure Mismatch** between the bulk processor and the template:

### What the Bulk Processor Stored (class-bulk-processor.php):
```php
$content_data = [
    "section_1" => [
        "id" => "general-questions",
        "title" => "General Questions",
        "questions" => [...]  // Array of questions
    ],
    "section_2" => [...],
    "section_3" => [...]
];
```

### What the Template Was Trying to Access (wordpress-interview-questions.php):
```php
// ❌ WRONG - These keys don't exist!
$section_id = $content_data["section_1_id"];
$section_title = $content_data["section_1_title"];
$questions_json = $content_data["section_1_questions_json"];
```

The template was looking for flat keys like `section_1_id`, `section_1_title`, `section_1_questions_json` but the actual data structure used nested arrays with keys `section_1`, `section_2`, etc.

## Files Modified

### 1. `/includes/templates/wordpress-interview-questions.php`

**Changes:**
- Fixed data structure access to use nested arrays
- Changed from `$content_data["section_{$i}_id"]` to `$content_data["section_{$i}"]['id']`
- Added comprehensive error logging for debugging
- Added validation checks for data structure

**Before:**
```php
for ($i = 1; $i <= 3; $i++) {
    $section_id = $content_data["section_{$i}_id"] ?? '';
    $section_title = $content_data["section_{$i}_title"] ?? '';
    $questions_json = $content_data["section_{$i}_questions_json"] ?? '';

    $questions = json_decode($questions_json, true);
    // ...
}
```

**After:**
```php
for ($i = 1; $i <= 3; $i++) {
    $section_key = "section_{$i}";

    if (!isset($content_data[$section_key])) {
        continue;
    }

    $section = $content_data[$section_key];
    $section_id = $section['id'] ?? '';
    $section_title = $section['title'] ?? '';
    $questions = $section['questions'] ?? [];  // Already an array!
    // ...
}
```

### 2. `/includes/admin/class-bulk-processor.php`

**Changes:**
- Added comprehensive logging for CSV import process
- Added JSON validation and error reporting
- Added UTF-8 BOM removal for CSV compatibility
- Added verification of stored data

**Key Improvements:**
- Logs each row being processed
- Logs JSON parsing success/failure
- Logs the number of questions parsed
- Verifies stored JSON can be decoded correctly
- Reports specific errors for each section

## How to Debug

### Step 1: Enable WordPress Debug Mode

Edit `wp-config.php` and add/update these lines:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
@ini_set('display_errors', 0);
```

### Step 2: Run the Debug Script

1. Upload `debug-interview-questions.php` to your WordPress root directory
2. Visit: `https://yoursite.com/debug-interview-questions.php`
3. Review the output for any errors
4. **DELETE the file after debugging** (security risk)

### Step 3: Check Debug Logs

View the WordPress debug log at:
```
/wp-content/debug.log
```

Look for lines starting with:
- `X0PA Debug -` (template debugging)
- `X0PA CSV Import -` (bulk import debugging)

### Step 4: Re-import CSV

After the fix:
1. Go to WordPress Admin → X0PA Hiring → Bulk Import
2. Select "Interview Questions"
3. Upload your CSV file again
4. Check the debug log for any errors
5. Visit the interview questions page

## Expected Debug Output

### Successful Import:
```
X0PA CSV Import - Processing row 2: Marketing Manager
X0PA CSV Import - Section 1 raw JSON (first 200 chars): [{"question":"Tell me about...
X0PA CSV Import - Section 1 successfully parsed 29 questions
X0PA CSV Import - Section 2 successfully parsed 15 questions
X0PA CSV Import - Section 3 successfully parsed 8 questions
X0PA CSV Import - Created content data with 3 sections
X0PA CSV Import - Created/updated post ID 123 for Marketing Manager
X0PA CSV Import - Content JSON length: 12567
X0PA CSV Import - Stored JSON decodes successfully, keys: Array ( [0] => section_1 [1] => section_2 [2] => section_3 )
```

### Successful Template Rendering:
```
X0PA Debug - Post ID: 123
X0PA Debug - Job Title: Marketing Manager
X0PA Debug - Content JSON: {"section_1":{"id":"general-questions","title":"General Questions"...
X0PA Debug - JSON Decode Error: No error
X0PA Debug - Content Data Keys: Array ( [0] => section_1 [1] => section_2 [2] => section_3 )
X0PA Debug - Rendering section 1 with 29 questions
X0PA Debug - Rendering section 2 with 15 questions
X0PA Debug - Rendering section 3 with 8 questions
```

## Common Issues and Solutions

### Issue 1: Still Showing "0 Questions"

**Cause:** Old data still in database from before the fix.

**Solution:** Re-import the CSV file. The bulk processor will update existing posts.

### Issue 2: JSON Parse Errors

**Cause:** CSV file has malformed JSON in the questions columns.

**Solution:**
1. Check the CSV file in a text editor
2. Ensure JSON fields use proper double quotes: `"question": "text"`
3. Ensure JSON is valid (use a JSON validator)
4. Check for special characters that need escaping

### Issue 3: Questions Cut Off

**Cause:** CSV parser might be truncating long JSON fields.

**Solution:**
1. Check PHP `max_input_vars` setting (increase if needed)
2. Ensure CSV doesn't have line breaks within JSON fields
3. Try uploading a smaller batch of rows

### Issue 4: Sections Missing

**Cause:** CSV columns for sections 2 or 3 are empty.

**Solution:**
1. Ensure CSV has columns: `section_1_id`, `section_1_title`, `section_1_questions_json`
2. If you only have section 1, that's fine - sections 2 and 3 are optional
3. Check for typos in column names (must be exact)

## CSV File Format

Your CSV must have these columns:

```
job_title,last_updated,section_1_id,section_1_title,section_1_questions_json,section_2_id,section_2_title,section_2_questions_json,section_3_id,section_3_title,section_3_questions_json
```

### Example Row:

```csv
Marketing Manager,2025-01-15,general-questions,General Questions,"[{""question"":""Tell me about your marketing experience"",""what_to_listen_for"":[""Specific campaigns"",""Measurable results""]}]",technical-questions,Technical Questions,"[{""question"":""What tools do you use?"",""what_to_listen_for"":[""Modern marketing platforms""]}]",,,
```

### Important:
- JSON fields must be properly escaped (double quotes inside become `""`)
- JSON must be valid (use a validator)
- Empty sections should have empty columns (just commas)
- UTF-8 encoding is required

## Testing Checklist

After applying the fix:

- [ ] Enable WP_DEBUG and WP_DEBUG_LOG
- [ ] Run debug-interview-questions.php script
- [ ] Re-upload CSV file
- [ ] Check debug.log for errors
- [ ] Visit interview questions page
- [ ] Verify correct number of questions displays
- [ ] Verify all sections render correctly
- [ ] Verify "What to Listen For" boxes show
- [ ] Test PDF download functionality
- [ ] Check question count in hero section
- [ ] Verify TOC/jump links work
- [ ] Delete debug-interview-questions.php

## Security Notes

1. **Delete debug-interview-questions.php after use** - it bypasses security for debugging
2. **Disable WP_DEBUG in production** - only use for troubleshooting
3. **Check file permissions** - wp-content/debug.log should not be publicly readable
4. **Clear debug.log regularly** - it can grow large and contain sensitive info

## Performance Considerations

The fix adds debug logging which has minimal performance impact:
- Logging only occurs when `WP_DEBUG` is enabled
- All logs use `error_log()` which is efficient
- No database queries added
- No significant processing overhead

For production:
- Disable `WP_DEBUG` after confirming fix works
- Remove debug-interview-questions.php
- Consider adding PHP opcode caching (OPcache)

## Need More Help?

If issues persist:

1. Check the full debug.log file
2. Run the debug script and send output
3. Check browser console for JavaScript errors
4. Verify all plugin files uploaded correctly
5. Try deactivating other plugins temporarily
6. Check PHP error logs (separate from WordPress)

## Additional Resources

- WordPress Debug Documentation: https://wordpress.org/support/article/debugging-in-wordpress/
- JSON Validator: https://jsonlint.com/
- CSV Validator: https://csvlint.io/
- PHP Error Logs: Usually in `/var/log/apache2/error.log` or similar
