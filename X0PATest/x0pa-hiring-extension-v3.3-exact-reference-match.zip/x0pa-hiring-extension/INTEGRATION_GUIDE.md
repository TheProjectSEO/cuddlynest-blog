# X0PA Hiring Extension - Integration Guide

Complete guide for integrating PHP logic components into WordPress templates.

---

## Table of Contents

1. [Setup & Initialization](#setup--initialization)
2. [Schema Integration](#schema-integration)
3. [Internal Linking](#internal-linking)
4. [Content Generators](#content-generators)
5. [Hub Page](#hub-page)
6. [Template Examples](#template-examples)
7. [Testing Recommendations](#testing-recommendations)

---

## Setup & Initialization

### Load Autoloader in Main Plugin File

**File:** `x0pa-hiring-extension.php`

```php
<?php
/**
 * Plugin Name: X0PA Hiring Extension
 * Description: SEO-optimized hiring pages with schemas and smart internal linking
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('X0PA_HIRING_VERSION', '1.0.0');
define('X0PA_HIRING_PATH', plugin_dir_path(__FILE__));
define('X0PA_HIRING_URL', plugin_dir_url(__FILE__));

// Load autoloader
require_once X0PA_HIRING_PATH . 'includes/class-autoloader.php';

// Plugin activation hook
register_activation_hook(__FILE__, 'x0pa_hiring_activate');

function x0pa_hiring_activate() {
    // Create hub page
    X0PA_Hub_Page::create_hub_page();

    // Flush rewrite rules
    flush_rewrite_rules();
}

// Plugin deactivation hook
register_deactivation_hook(__FILE__, 'x0pa_hiring_deactivate');

function x0pa_hiring_deactivate() {
    // Clear caches
    X0PA_Hub_Page::clear_cache();
    X0PA_Internal_Linking::clear_all_caches();

    flush_rewrite_rules();
}
```

---

## Schema Integration

### 1. WebPage Schema (All Pages)

**When:** In page template `<head>` section

```php
<?php
// In single-x0pa_hiring_page.php template
get_header();

global $post;

// Generate SEO metadata
$content = get_post_meta($post->ID, '_x0pa_content_json', true);
$seo_meta = X0PA_SEO_Meta::generate($post, $content);

// Output WebPage schema
X0PA_WebPage_Schema::output_schema($post);
?>
```

### 2. FAQ Schema (Interview Questions Pages Only)

**When:** After main content, only if sufficient questions exist

```php
<?php
$page_type = get_post_meta($post->ID, '_x0pa_page_type', true);

if ($page_type === 'interview-questions') {
    $content_json = get_post_meta($post->ID, '_x0pa_content_json', true);

    // Generate FAQ schema from structured content
    if (X0PA_FAQ_Schema::has_sufficient_questions($content_json, 3)) {
        X0PA_FAQ_Schema::output_schema($content_json, 3);
    }
}
?>
```

### 3. Author Schema (All Pages)

**When:** In page template `<head>` section

```php
<?php
// Output author schema
X0PA_Author_Schema::output_schema();
?>
```

### Complete Schema Implementation Example

```php
<?php
/**
 * Template: single-x0pa_hiring_page.php
 */

get_header();

global $post;

// Get page metadata
$job_title = get_post_meta($post->ID, '_x0pa_job_title', true);
$page_type = get_post_meta($post->ID, '_x0pa_page_type', true);
$content_json = get_post_meta($post->ID, '_x0pa_content_json', true);

// Generate SEO metadata
$seo_meta = X0PA_SEO_Meta::generate($post, $content_json);
?>

<head>
    <?php
    // Output meta tags
    X0PA_SEO_Meta::output_meta_tags($seo_meta);

    // Output schemas
    X0PA_WebPage_Schema::output_schema($post);
    X0PA_Author_Schema::output_schema();

    // Output FAQ schema (interview questions only)
    if ($page_type === 'interview-questions') {
        X0PA_FAQ_Schema::output_schema($content_json, 3);
    }

    wp_head();
    ?>
</head>
```

---

## Internal Linking

### Get Related Pages (Same Page Type)

```php
<?php
$job_title = get_post_meta($post->ID, '_x0pa_job_title', true);
$page_type = get_post_meta($post->ID, '_x0pa_page_type', true);

// Get 4 most related pages
$related_pages = X0PA_Internal_Linking::get_related_pages(
    $job_title,
    $page_type,
    $post->ID,
    4
);

// Render related pages
if (!empty($related_pages)) {
    echo X0PA_Internal_Linking::render_related_pages(
        $related_pages,
        'Related Interview Questions'
    );
}
?>
```

### Get Complementary Pages (Opposite Page Type)

```php
<?php
// Get both interview questions and job descriptions for same job
$complementary = X0PA_Internal_Linking::get_complementary_pages(
    $job_title,
    $post->ID,
    2 // 2 of each type
);

// Interview questions
if (!empty($complementary['interview-questions'])) {
    echo X0PA_Internal_Linking::render_related_pages(
        $complementary['interview-questions'],
        'Interview Questions'
    );
}

// Job descriptions
if (!empty($complementary['job-description'])) {
    echo X0PA_Internal_Linking::render_related_pages(
        $complementary['job-description'],
        'Job Description Templates'
    );
}
?>
```

### Clear Cache on Post Update

**File:** `includes/admin/class-admin.php`

```php
<?php
// Clear internal linking cache when post is saved
add_action('save_post_x0pa_hiring_page', function($post_id) {
    X0PA_Internal_Linking::clear_post_cache($post_id);
    X0PA_Hub_Page::clear_cache(); // Also clear hub page cache
});
?>
```

---

## Content Generators

### 1. Hero Section

```php
<?php
// Generate hero section
$seo_meta = X0PA_SEO_Meta::generate($post, $content_json);
$hero_html = X0PA_Hero_Generator::generate($post, $seo_meta);

echo $hero_html;
?>
```

### 2. Table of Contents

```php
<?php
// Generate TOC from content JSON
$toc_sections = X0PA_TOC_Generator::generate_from_content($content_json);

// Render sidebar TOC with ScrollSpy
echo X0PA_TOC_Generator::render_jump_links($toc_sections, 'questions-overview');

// Render mobile TOC dropdown
echo X0PA_TOC_Generator::render_mobile_toc($toc_sections);

// Add ScrollSpy JavaScript
echo X0PA_TOC_Generator::generate_scrollspy_script($toc_sections);
?>
```

### 3. Interview Overview (Interview Questions Only)

```php
<?php
if ($page_type === 'interview-questions') {
    // Generate overview card
    echo X0PA_Interview_Overview::generate($content_json, $job_title);

    // Or use compact version
    echo X0PA_Interview_Overview::generate_compact($content_json);

    // Or just category navigation
    echo X0PA_Interview_Overview::generate_category_nav($content_json);
}
?>
```

### 4. SEO Metadata & Reading Time

```php
<?php
// Generate SEO metadata
$seo_meta = X0PA_SEO_Meta::generate($post, $content_json);

// Display reading time
$reading_time = $seo_meta['reading_time'];
echo '<span class="reading-time">' . X0PA_SEO_Meta::format_reading_time($reading_time) . '</span>';

// Display word count
$word_count = $seo_meta['word_count'];
echo '<span class="word-count">' . number_format($word_count) . ' words</span>';
?>
```

---

## Hub Page

### Create Hub Page on Activation

Already handled in plugin activation hook (see Setup section above).

### Display Hub Page Content

**Template:** `templates/x0pa-hub-page.php`

```php
<?php
/**
 * Template Name: X0PA Hub Page
 */

get_header();
?>

<main id="hub-page-content">
    <?php
    // Render hub page content
    echo X0PA_Hub_Page::render_hub_page();
    ?>
</main>

<?php
get_footer();
?>
```

### Hub Page Statistics

```php
<?php
// Get statistics for admin dashboard
$stats = X0PA_Hub_Page::get_statistics();

echo "Total Job Titles: " . $stats['total_job_titles'];
echo "Interview Questions: " . $stats['total_interview_questions'];
echo "Job Descriptions: " . $stats['total_job_descriptions'];
echo "Complete Sets: " . $stats['complete_sets'];
?>
```

### Hub Page URL for Navigation

```php
<?php
// Get hub page URL
$hub_url = X0PA_Hub_Page::get_hub_page_url();

if ($hub_url) {
    echo '<a href="' . esc_url($hub_url) . '">View All Hiring Resources</a>';
}
?>
```

---

## Template Examples

### Complete Single Page Template

**File:** `templates/single-x0pa_hiring_page.php`

```php
<?php
/**
 * Single Hiring Page Template
 */

get_header();

global $post;

// Get metadata
$job_title = get_post_meta($post->ID, '_x0pa_job_title', true);
$page_type = get_post_meta($post->ID, '_x0pa_page_type', true);
$content_json = get_post_meta($post->ID, '_x0pa_content_json', true);

// Generate SEO metadata
$seo_meta = X0PA_SEO_Meta::generate($post, $content_json);

// Generate TOC
$toc_sections = X0PA_TOC_Generator::generate_from_content($content_json);
?>

<head>
    <?php
    // SEO Meta Tags
    X0PA_SEO_Meta::output_meta_tags($seo_meta);

    // Schemas
    X0PA_WebPage_Schema::output_schema($post);
    X0PA_Author_Schema::output_schema();

    if ($page_type === 'interview-questions') {
        X0PA_FAQ_Schema::output_schema($content_json, 3);
    }

    wp_head();
    ?>
</head>

<body <?php body_class(); ?>>

<!-- Hero Section -->
<?php echo X0PA_Hero_Generator::generate($post, $seo_meta); ?>

<div class="page-layout">
    <!-- Sidebar TOC -->
    <aside class="page-sidebar">
        <?php echo X0PA_TOC_Generator::render_jump_links($toc_sections); ?>
    </aside>

    <!-- Main Content -->
    <main class="page-content" id="main-content">
        <!-- Mobile TOC -->
        <div class="mobile-toc">
            <?php echo X0PA_TOC_Generator::render_mobile_toc($toc_sections); ?>
        </div>

        <!-- Interview Overview (if applicable) -->
        <?php
        if ($page_type === 'interview-questions') {
            echo X0PA_Interview_Overview::generate($content_json, $job_title);
        }
        ?>

        <!-- Main Content Sections -->
        <div class="content-sections">
            <?php
            // Render your content sections here
            // This would come from the CSV import
            ?>
        </div>

        <!-- Related Pages -->
        <section class="related-pages">
            <h2>Related Resources</h2>

            <?php
            // Get related pages (same type)
            $related = X0PA_Internal_Linking::get_related_pages(
                $job_title,
                $page_type,
                $post->ID,
                4
            );

            echo X0PA_Internal_Linking::render_related_pages(
                $related,
                'Related ' . ($page_type === 'interview-questions' ? 'Interview Questions' : 'Job Descriptions')
            );
            ?>
        </section>

        <!-- Author Byline -->
        <div class="author-section">
            <?php echo X0PA_Author_Schema::get_author_byline(true); ?>
        </div>
    </main>
</div>

<!-- ScrollSpy Script -->
<?php echo X0PA_TOC_Generator::generate_scrollspy_script($toc_sections); ?>

<?php
wp_footer();
?>
</body>
```

---

## Testing Recommendations

### 1. Schema Validation

**Tools:**
- Google Rich Results Test: https://search.google.com/test/rich-results
- Schema.org Validator: https://validator.schema.org/

**Test Cases:**
```php
// Test WebPage Schema
$webpage_schema = X0PA_WebPage_Schema::generate($post);
echo '<pre>' . $webpage_schema . '</pre>';

// Test FAQ Schema
$faq_schema = X0PA_FAQ_Schema::generate($content_json, 3);
echo '<pre>' . $faq_schema . '</pre>';

// Test Author Schema
$author_schema = X0PA_Author_Schema::get_json_ld(false);
echo '<pre>' . $author_schema . '</pre>';
```

### 2. Internal Linking Algorithm

**Test Similarity Scores:**
```php
// Debug similarity scores (requires WP_DEBUG = true)
$related = X0PA_Internal_Linking::get_related_pages(
    'Senior Software Engineer',
    'interview-questions',
    123,
    10
);

// Scores will show in output when WP_DEBUG is true
var_dump($related);
```

**Verify Self-Exclusion:**
```php
// Ensure current page is NEVER in related pages
$current_id = $post->ID;
$related = X0PA_Internal_Linking::get_related_pages($job_title, $page_type, $current_id, 4);

foreach ($related as $page) {
    assert($page['post_id'] !== $current_id, 'Current page should be excluded');
}
```

### 3. Cache Performance

**Verify Caching:**
```php
// First call - should query database
$start = microtime(true);
$related = X0PA_Internal_Linking::get_related_pages($job_title, $page_type, $post->ID, 4);
$time1 = microtime(true) - $start;

// Second call - should use cache
$start = microtime(true);
$related = X0PA_Internal_Linking::get_related_pages($job_title, $page_type, $post->ID, 4);
$time2 = microtime(true) - $start;

echo "First call: {$time1}s, Second call: {$time2}s";
// Second call should be significantly faster
```

### 4. Content Generators

**Test TOC Generation:**
```php
$toc = X0PA_TOC_Generator::generate_from_content($content_json);
assert(is_array($toc), 'TOC should be an array');
assert(!empty($toc), 'TOC should not be empty');

foreach ($toc as $section) {
    assert(isset($section['id']), 'Section should have ID');
    assert(isset($section['title']), 'Section should have title');
    assert(isset($section['count']), 'Section should have count');
}
```

**Test Reading Time:**
```php
$content = str_repeat('word ', 1000); // 1000 words
$reading_time = X0PA_SEO_Meta::calculate_reading_time($content);
assert($reading_time === 5, 'Reading time should be 5 minutes for 1000 words');
```

### 5. Hub Page

**Test Hub Page Creation:**
```php
// Create hub page
$page_id = X0PA_Hub_Page::create_hub_page();
assert(is_numeric($page_id), 'Should return page ID');

// Verify page exists
$page = get_post($page_id);
assert($page->post_type === 'page', 'Should be a page');
assert($page->post_name === 'hiring', 'Should have correct slug');
```

**Test Grouped Pages:**
```php
$grouped = X0PA_Hub_Page::get_grouped_pages(false); // No cache
assert(is_array($grouped), 'Should return array');

foreach ($grouped as $job_title => $data) {
    assert(isset($data['job_title']), 'Should have job_title');
    assert(isset($data['pages']), 'Should have pages array');
}
```

### 6. Error Handling

**Test Invalid Input:**
```php
// Test with null post
$schema = X0PA_WebPage_Schema::generate(null);
assert(empty($schema), 'Should return empty string for null post');

// Test with empty content
$toc = X0PA_TOC_Generator::generate_from_content('');
assert(empty($toc), 'Should return empty array for empty content');

// Test with invalid JSON
$toc = X0PA_TOC_Generator::generate_from_content('invalid json');
assert(empty($toc), 'Should handle invalid JSON gracefully');
```

### 7. Performance Benchmarks

**Expected Performance:**
- Schema generation: < 50ms per page
- Internal linking (cached): < 10ms
- Internal linking (uncached): < 500ms for 100 pages
- TOC generation: < 100ms
- Hub page render: < 300ms for 50 job titles

**Benchmark Script:**
```php
function benchmark_function($callback, $iterations = 10) {
    $start = microtime(true);

    for ($i = 0; $i < $iterations; $i++) {
        $callback();
    }

    $time = microtime(true) - $start;
    $avg = $time / $iterations;

    echo "Total: {$time}s, Average: {$avg}s\n";
}

// Benchmark schema generation
benchmark_function(function() use ($post) {
    X0PA_WebPage_Schema::generate($post);
});
```

---

## Advanced Usage

### Custom Filters

```php
// Filter related pages before rendering
add_filter('x0pa_related_pages', function($pages, $job_title, $page_type) {
    // Custom logic to modify related pages
    return $pages;
}, 10, 3);

// Filter hub page statistics
add_filter('x0pa_hub_statistics', function($stats) {
    // Add custom statistics
    $stats['custom_metric'] = 100;
    return $stats;
});
```

### Custom Actions

```php
// Action when hub page is created
add_action('x0pa_hub_page_created', function($page_id) {
    // Custom logic after hub page creation
});

// Action when cache is cleared
add_action('x0pa_cache_cleared', function($type) {
    // Custom logic after cache clear
});
```

---

## Troubleshooting

### Schemas Not Showing

1. Check if `wp_head()` is called in template
2. Verify post meta data is saved correctly
3. Use Google Rich Results Test to validate

### Internal Links Not Working

1. Clear cache: `X0PA_Internal_Linking::clear_all_caches()`
2. Check if pages have `_x0pa_job_title` and `_x0pa_page_type` meta
3. Verify pages are published

### Hub Page Not Found

1. Re-save permalinks in WordPress admin
2. Check if page exists: `X0PA_Hub_Page::get_hub_page_id()`
3. Manually create if needed: `X0PA_Hub_Page::create_hub_page()`

### Performance Issues

1. Enable object caching (Redis/Memcached)
2. Check cache hit rate
3. Optimize database queries with proper indexes

---

## Next Steps

1. **Create page templates** using the examples above
2. **Import CSV data** to test with real content
3. **Validate schemas** with Google tools
4. **Test internal linking** with 10+ pages
5. **Performance test** with production-like data
6. **Mobile responsive** testing for TOC and hero

---

## File Locations

```
x0pa-hiring-extension/
├── includes/
│   ├── class-autoloader.php          ← Load this first
│   ├── core/
│   │   ├── class-internal-linking.php
│   │   └── class-hub-page.php
│   ├── schemas/
│   │   ├── class-webpage-schema.php
│   │   ├── class-author-schema.php
│   │   └── class-faq-schema.php
│   └── generators/
│       ├── class-seo-meta.php
│       ├── class-toc-generator.php
│       ├── class-hero-generator.php
│       └── class-interview-overview.php
└── templates/
    ├── single-x0pa_hiring_page.php    ← Create this
    └── x0pa-hub-page.php               ← Create this
```

---

## Support & Documentation

For questions or issues, refer to:
- Schema.org documentation: https://schema.org
- WordPress Template Hierarchy: https://developer.wordpress.org/themes/basics/template-hierarchy/
- PHP PSR-12 Standards: https://www.php-fig.org/psr/psr-12/
