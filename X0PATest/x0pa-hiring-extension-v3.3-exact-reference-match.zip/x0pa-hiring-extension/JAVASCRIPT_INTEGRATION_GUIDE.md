# JavaScript Integration Guide
## X0PA Hiring Extension Plugin

**Version:** 1.0.0
**Last Updated:** January 2025

---

## Table of Contents

1. [Overview](#overview)
2. [File Structure](#file-structure)
3. [WordPress Integration](#wordpress-integration)
4. [Script Dependencies](#script-dependencies)
5. [Usage Instructions](#usage-instructions)
6. [Browser Compatibility](#browser-compatibility)
7. [Performance Considerations](#performance-considerations)
8. [Debugging & Testing](#debugging--testing)

---

## Overview

The X0PA Hiring Extension includes three core JavaScript files that handle:

- **hiring-script.js**: ScrollSpy, sticky sidebars, section navigation
- **hubspot-pdf-gate.js**: PDF download modals with HubSpot form gating
- **hubspot-newsletter.js**: Newsletter signup forms with HubSpot integration

All scripts are written in vanilla JavaScript (ES6+) with no jQuery dependency.

---

## File Structure

```
x0pa-hiring-extension/
└── includes/
    └── assets/
        └── js/
            ├── hiring-script.js         (Main functionality)
            ├── hubspot-pdf-gate.js      (PDF downloads)
            └── hubspot-newsletter.js    (Newsletter signups)
```

---

## WordPress Integration

### Enqueueing Scripts in PHP

Add to your theme's `functions.php` or plugin's main file:

```php
<?php
/**
 * Enqueue X0PA JavaScript files
 */
function x0pa_enqueue_scripts() {
    // Main hiring script (all pages with hiring content)
    wp_enqueue_script(
        'x0pa-hiring-script',
        plugin_dir_url(__FILE__) . 'includes/assets/js/hiring-script.js',
        array(), // No dependencies
        '1.0.0',
        true // Load in footer
    );

    // PDF gate script (only on hiring guide pages)
    if (is_singular('hiring_guide')) {
        wp_enqueue_script(
            'x0pa-pdf-gate',
            plugin_dir_url(__FILE__) . 'includes/assets/js/hubspot-pdf-gate.js',
            array('x0pa-hiring-script'),
            '1.0.0',
            true
        );

        // Pass PDF data to JavaScript
        wp_localize_script('x0pa-pdf-gate', 'x0paPDFData', array(
            'pdfUrl' => get_post_meta(get_the_ID(), 'pdf_url', true),
            'pdfTitle' => get_the_title(),
            'hubspotPortalId' => get_option('x0pa_hubspot_portal_id'),
            'hubspotFormId' => get_option('x0pa_hubspot_pdf_form_id')
        ));
    }

    // Newsletter script (all pages with newsletter form)
    wp_enqueue_script(
        'x0pa-newsletter',
        plugin_dir_url(__FILE__) . 'includes/assets/js/hubspot-newsletter.js',
        array(),
        '1.0.0',
        true
    );

    // Pass HubSpot config to newsletter script
    wp_localize_script('x0pa-newsletter', 'x0paNewsletterData', array(
        'hubspotPortalId' => get_option('x0pa_hubspot_portal_id'),
        'hubspotFormId' => get_option('x0pa_hubspot_newsletter_form_id')
    ));
}
add_action('wp_enqueue_scripts', 'x0pa_enqueue_scripts');
```

### HubSpot Forms Script

Add HubSpot Forms API to your theme header:

```php
<?php
/**
 * Add HubSpot Forms API script
 */
function x0pa_add_hubspot_forms() {
    ?>
    <script charset="utf-8" type="text/javascript" src="//js.hsforms.net/forms/v2.js"></script>
    <?php
}
add_action('wp_head', 'x0pa_add_hubspot_forms');
```

---

## Script Dependencies

### hiring-script.js

**Dependencies:** None (vanilla JS)

**Required HTML Structure:**
- Content sections with class `.content-section` and unique IDs
- Navigation links with class `.jump-link` and `href="#section-id"`
- Sidebar container with class `.hiring-sidebar`

**Initialization:**
```javascript
// Call from your template file after DOM content loads
<script>
document.addEventListener('DOMContentLoaded', function() {
    if (typeof initScrollSpy !== 'undefined') {
        initScrollSpy('questions-overview'); // First section ID
    }
});
</script>
```

### hubspot-pdf-gate.js

**Dependencies:**
- HubSpot Forms API (//js.hsforms.net/forms/v2.js)
- hiring-script.js (for modal structure)

**Required HTML Structure:**
```html
<!-- PDF Download Buttons -->
<button id="pdf-download-btn-sidebar" class="btn btn-primary">
    Download PDF
</button>

<button id="pdf-download-btn-hero" class="btn btn-secondary">
    Get Free Guide
</button>

<!-- PDF Data (set via PHP) -->
<div data-pdf-url="<?php echo esc_url($pdf_url); ?>"
     data-pdf-title="<?php echo esc_attr($pdf_title); ?>"></div>

<!-- Modal Structure -->
<div id="pdf-download-modal" class="modal hidden">
    <div class="modal-overlay"></div>
    <div class="modal-content">
        <button class="modal-close">&times;</button>
        <div id="hubspot-pdf-form"></div>
    </div>
</div>
```

**HubSpot Form Embed:**
```html
<div id="hubspot-pdf-form"></div>
<script>
hbspt.forms.create({
    region: "na1",
    portalId: "YOUR_PORTAL_ID",
    formId: "YOUR_FORM_ID",
    target: "#hubspot-pdf-form"
});
</script>
```

### hubspot-newsletter.js

**Dependencies:**
- HubSpot Forms API (//js.hsforms.net/forms/v2.js)

**Required HTML Structure:**
```html
<form id="newsletter-form"
      data-portal-id="YOUR_PORTAL_ID"
      data-form-id="YOUR_FORM_ID">
    <div class="form-group">
        <label for="newsletter-email">Email Address</label>
        <input type="email"
               id="newsletter-email"
               name="email"
               placeholder="you@example.com"
               required>
    </div>
    <button type="submit" class="newsletter-submit btn btn-primary">
        Subscribe
    </button>
</form>
```

---

## Usage Instructions

### 1. ScrollSpy Navigation

**Template Implementation:**

```php
<!-- In your hiring guide template -->
<div class="hiring-content-wrapper">
    <!-- Sidebar with TOC -->
    <aside class="hiring-sidebar">
        <nav class="jump-links">
            <ul>
                <li><a href="#questions-overview" class="jump-link">Overview</a></li>
                <li><a href="#technical-skills" class="jump-link">Technical Skills</a></li>
                <li><a href="#behavioral-questions" class="jump-link">Behavioral</a></li>
            </ul>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="hiring-content">
        <section id="questions-overview" class="content-section">
            <h2>Questions Overview</h2>
            <!-- Content -->
        </section>

        <section id="technical-skills" class="content-section">
            <h2>Technical Skills Assessment</h2>
            <!-- Content -->
        </section>

        <section id="behavioral-questions" class="content-section">
            <h2>Behavioral Questions</h2>
            <!-- Content -->
        </section>
    </main>
</div>

<script>
// Initialize ScrollSpy with first section ID
document.addEventListener('DOMContentLoaded', function() {
    if (typeof initScrollSpy !== 'undefined') {
        initScrollSpy('questions-overview');
    }
});
</script>
```

**CSS Requirements:**

```css
/* Active state for TOC links */
.jump-link.active {
    color: #0066cc;
    font-weight: 600;
}

/* Sticky sidebar (handled by JS, but can override) */
.hiring-sidebar {
    position: sticky;
    top: 80px; /* Adjust based on header height */
}

/* Mobile menu toggle (if using) */
@media (max-width: 1023px) {
    .hiring-sidebar {
        position: fixed;
        top: 0;
        left: -100%;
        transition: left 0.3s ease;
    }

    .hiring-sidebar.mobile-open {
        left: 0;
    }
}
```

### 2. PDF Download Gate

**Complete Implementation:**

```php
<!-- In your hiring guide template -->

<!-- PDF Download Buttons -->
<div class="hero-cta">
    <button id="pdf-download-btn-hero" class="btn btn-primary btn-lg">
        Download Free Interview Guide
    </button>
</div>

<aside class="hiring-sidebar">
    <div class="sidebar-cta">
        <button id="pdf-download-btn-sidebar" class="btn btn-outline">
            Get PDF Version
        </button>
    </div>
</aside>

<!-- PDF Data (passed from PHP) -->
<div data-pdf-url="<?php echo esc_url(get_post_meta(get_the_ID(), 'pdf_url', true)); ?>"
     data-pdf-title="<?php echo esc_attr(get_the_title()); ?>"></div>

<!-- Modal -->
<div id="pdf-download-modal" class="modal hidden">
    <div class="modal-overlay"></div>
    <div class="modal-content max-w-md">
        <button class="modal-close" aria-label="Close modal">&times;</button>

        <div class="modal-header">
            <h3>Download Your Free Guide</h3>
            <p>Enter your email to receive the PDF instantly.</p>
        </div>

        <!-- HubSpot Form Container -->
        <div id="hubspot-pdf-form"></div>
    </div>
</div>

<!-- HubSpot Form Initialization -->
<script>
hbspt.forms.create({
    region: "na1",
    portalId: "<?php echo get_option('x0pa_hubspot_portal_id'); ?>",
    formId: "<?php echo get_option('x0pa_hubspot_pdf_form_id'); ?>",
    target: "#hubspot-pdf-form",
    onFormSubmitted: function() {
        console.log('Form submitted - handled by hubspot-pdf-gate.js');
    }
});
</script>
```

**Modal Styling (Tailwind CSS):**

```css
/* Modal Base */
.modal {
    position: fixed;
    inset: 0;
    z-index: 9999;
    background-color: rgba(0, 0, 0, 0.75);
    align-items: center;
    justify-content: center;
}

.modal.hidden {
    display: none;
}

.modal-content {
    background: white;
    border-radius: 8px;
    padding: 2rem;
    max-width: 28rem;
    width: 90%;
    max-height: 90vh;
    overflow-y: auto;
    position: relative;
}

.modal-close {
    position: absolute;
    top: 1rem;
    right: 1rem;
    font-size: 1.5rem;
    background: none;
    border: none;
    cursor: pointer;
}
```

### 3. Newsletter Signup

**Template Implementation:**

```php
<!-- In footer.php or newsletter section -->
<section class="newsletter-section">
    <div class="container">
        <h3>Stay Updated on Hiring Trends</h3>
        <p>Get expert insights delivered to your inbox monthly.</p>

        <form id="newsletter-form"
              data-portal-id="<?php echo get_option('x0pa_hubspot_portal_id'); ?>"
              data-form-id="<?php echo get_option('x0pa_hubspot_newsletter_form_id'); ?>">

            <div class="form-group">
                <label for="newsletter-email" class="sr-only">Email Address</label>
                <input type="email"
                       id="newsletter-email"
                       name="email"
                       placeholder="your.email@company.com"
                       required
                       aria-required="true">
            </div>

            <button type="submit" class="newsletter-submit btn btn-primary">
                Subscribe to Newsletter
            </button>
        </form>
    </div>
</section>
```

**Loading/Success States CSS:**

```css
/* Loading State */
.newsletter-submit.loading {
    opacity: 0.7;
    cursor: not-allowed;
    position: relative;
}

.spinner {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

/* Success State */
.newsletter-submit.success {
    background-color: #10b981;
    border-color: #10b981;
}

/* Error State */
.newsletter-submit.error {
    background-color: #ef4444;
    border-color: #ef4444;
}

/* Form Messages */
.form-message {
    margin-top: 1rem;
    padding: 0.75rem 1rem;
    border-radius: 4px;
    font-size: 0.875rem;
}

.form-message--success {
    background-color: #d1fae5;
    color: #065f46;
}

.form-message--error {
    background-color: #fee2e2;
    color: #991b1b;
}

.form-message.fade-out {
    opacity: 0;
    transition: opacity 0.3s ease;
}

/* Input Error State */
.newsletter-email.error {
    border-color: #ef4444;
}

.input-error {
    display: block;
    color: #ef4444;
    font-size: 0.75rem;
    margin-top: 0.25rem;
}
```

---

## Browser Compatibility

### Supported Browsers

| Browser | Minimum Version | Notes |
|---------|----------------|-------|
| Chrome | 90+ | Full support |
| Firefox | 88+ | Full support |
| Safari | 14+ | Full support |
| Edge | 90+ | Full support |
| iOS Safari | 14+ | Full support |
| Android Chrome | 90+ | Full support |

### Required JavaScript Features

- **Intersection Observer API** (ScrollSpy)
- **Fetch API** (Newsletter submission)
- **ES6+ Syntax** (Arrow functions, destructuring, const/let)
- **Cookies API** (PDF download tracking)
- **PostMessage API** (HubSpot form callbacks)

### Polyfills (if supporting older browsers)

```html
<!-- Add before your scripts if supporting IE11 or older browsers -->
<script src="https://polyfill.io/v3/polyfill.min.js?features=IntersectionObserver%2Cfetch%2Ces6"></script>
```

---

## Performance Considerations

### Loading Strategy

1. **Defer/Async Loading**: All scripts load in footer with `defer` attribute
2. **Conditional Loading**: PDF gate only loads on hiring guide pages
3. **No jQuery**: Reduces payload by ~30KB
4. **Minification**: Minify for production (reduces size by ~40%)

### Optimization Tips

```php
// In production, use minified versions
function x0pa_enqueue_scripts() {
    $suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';

    wp_enqueue_script(
        'x0pa-hiring-script',
        plugin_dir_url(__FILE__) . "includes/assets/js/hiring-script{$suffix}.js",
        array(),
        '1.0.0',
        true
    );
}
```

### Build Process (Optional)

Use a build tool to minify:

```bash
# Using Terser
npm install -g terser

# Minify hiring-script.js
terser hiring-script.js -o hiring-script.min.js -c -m

# Minify all files
terser hubspot-pdf-gate.js -o hubspot-pdf-gate.min.js -c -m
terser hubspot-newsletter.js -o hubspot-newsletter.min.js -c -m
```

---

## Debugging & Testing

### Debug Mode

All scripts include debug utilities in development environments:

```javascript
// In browser console (localhost or staging)

// PDF Gate Debugging
window.X0PA_PDF_Debug.clearCookie();    // Clear download cookie
window.X0PA_PDF_Debug.showModal();      // Show PDF modal
window.X0PA_PDF_Debug.triggerDownload(); // Trigger download

// Newsletter Debugging
window.X0PA_Newsletter_Debug.validateEmail('test@example.com'); // Test validation
window.X0PA_Newsletter_Debug.showLoading();  // Show loading state
window.X0PA_Newsletter_Debug.showSuccess();  // Show success state
window.X0PA_Newsletter_Debug.showError();    // Show error state
```

### Console Logging

Enable verbose logging:

```javascript
// Check console for initialization messages
// X0PA: Scripts initialized
// X0PA: Newsletter form initialized
// X0PA: PDF gate initialized successfully
```

### Testing Checklist

**ScrollSpy:**
- [ ] Active state updates on scroll
- [ ] Smooth scrolling works on link click
- [ ] Sticky sidebar works on desktop
- [ ] Sidebar unsticks on mobile
- [ ] First section highlighted on load

**PDF Gate:**
- [ ] Modal opens on button click (first-time users)
- [ ] Direct download works (returning users)
- [ ] HubSpot form submits successfully
- [ ] PDF downloads after form submission
- [ ] Cookie persists for 90 days
- [ ] Modal closes on outside click/Escape

**Newsletter:**
- [ ] Email validation works
- [ ] Loading state shows during submission
- [ ] Success message appears after submission
- [ ] Error handling works for failed submissions
- [ ] Form resets after successful submission
- [ ] Analytics events fire correctly

### Common Issues & Solutions

**Issue: ScrollSpy not working**
```javascript
// Check if sections and links exist
console.log(document.querySelectorAll('.content-section').length);
console.log(document.querySelectorAll('.jump-link').length);

// Ensure initScrollSpy is called after DOM loads
document.addEventListener('DOMContentLoaded', function() {
    if (typeof initScrollSpy !== 'undefined') {
        initScrollSpy('first-section-id');
    } else {
        console.error('initScrollSpy not defined - check script loading');
    }
});
```

**Issue: HubSpot form not loading**
```javascript
// Check if HubSpot API loaded
console.log(typeof window.hbspt); // Should be 'object'

// Check form configuration
console.log(document.querySelector('[data-portal-id]').dataset);
```

**Issue: PDF not downloading**
```javascript
// Check PDF URL
const pdfData = document.querySelector('[data-pdf-url]');
console.log(pdfData.getAttribute('data-pdf-url'));

// Check cookie
console.log(document.cookie.includes('x0pa_pdf_downloaded'));
```

---

## Integration with WordPress Templates

### Full Template Example

```php
<?php
/**
 * Template: Hiring Guide Detail Page
 * Integrates all three JavaScript files
 */

get_header();
?>

<div class="hiring-guide-wrapper">
    <!-- Hero Section with PDF Download -->
    <section class="hero bg-gradient">
        <div class="container">
            <h1><?php the_title(); ?></h1>
            <p class="lead"><?php echo get_post_meta(get_the_ID(), 'subtitle', true); ?></p>

            <button id="pdf-download-btn-hero" class="btn btn-primary btn-lg">
                Download Free PDF Guide
            </button>
        </div>
    </section>

    <!-- Main Content with Sidebar -->
    <div class="hiring-content-wrapper container">
        <!-- Sidebar with TOC -->
        <aside class="hiring-sidebar">
            <div class="sidebar-sticky">
                <h3 class="sidebar-title">Table of Contents</h3>
                <nav class="jump-links">
                    <ul>
                        <?php
                        // Get sections from ACF or custom field
                        $sections = get_post_meta(get_the_ID(), 'sections', true);
                        $first_section = '';

                        foreach ($sections as $index => $section) {
                            if ($index === 0) {
                                $first_section = sanitize_title($section['title']);
                            }
                            $section_id = sanitize_title($section['title']);
                            ?>
                            <li>
                                <a href="#<?php echo esc_attr($section_id); ?>" class="jump-link">
                                    <?php echo esc_html($section['title']); ?>
                                </a>
                            </li>
                            <?php
                        }
                        ?>
                    </ul>
                </nav>

                <!-- Sidebar CTA -->
                <div class="sidebar-cta">
                    <button id="pdf-download-btn-sidebar" class="btn btn-outline btn-block">
                        Download PDF
                    </button>
                </div>
            </div>
        </aside>

        <!-- Main Content -->
        <main class="hiring-content">
            <?php
            foreach ($sections as $section) {
                $section_id = sanitize_title($section['title']);
                ?>
                <section id="<?php echo esc_attr($section_id); ?>" class="content-section">
                    <h2><?php echo esc_html($section['title']); ?></h2>
                    <div class="section-content">
                        <?php echo wp_kses_post($section['content']); ?>
                    </div>
                </section>
                <?php
            }
            ?>
        </main>
    </div>

    <!-- Newsletter Section -->
    <section class="newsletter-section bg-gray-50">
        <div class="container text-center">
            <h2>Stay Updated on Hiring Best Practices</h2>
            <p>Get monthly insights delivered to your inbox.</p>

            <form id="newsletter-form"
                  data-portal-id="<?php echo get_option('x0pa_hubspot_portal_id'); ?>"
                  data-form-id="<?php echo get_option('x0pa_hubspot_newsletter_form_id'); ?>"
                  class="newsletter-form-inline">
                <input type="email"
                       id="newsletter-email"
                       placeholder="your.email@company.com"
                       required>
                <button type="submit" class="newsletter-submit btn btn-primary">
                    Subscribe
                </button>
            </form>
        </div>
    </section>
</div>

<!-- PDF Download Modal -->
<div id="pdf-download-modal" class="modal hidden">
    <div class="modal-overlay"></div>
    <div class="modal-content">
        <button class="modal-close" aria-label="Close">&times;</button>
        <div class="modal-header">
            <h3>Download <?php the_title(); ?></h3>
            <p>Get instant access to the complete guide.</p>
        </div>
        <div id="hubspot-pdf-form"></div>
    </div>
</div>

<!-- PDF Data for JavaScript -->
<div data-pdf-url="<?php echo esc_url(get_post_meta(get_the_ID(), 'pdf_url', true)); ?>"
     data-pdf-title="<?php echo esc_attr(get_the_title()); ?>"></div>

<!-- Initialize Scripts -->
<script>
// Initialize ScrollSpy with first section
document.addEventListener('DOMContentLoaded', function() {
    if (typeof initScrollSpy !== 'undefined') {
        initScrollSpy('<?php echo esc_js($first_section); ?>');
    }
});

// Initialize HubSpot PDF Form
hbspt.forms.create({
    region: "na1",
    portalId: "<?php echo esc_js(get_option('x0pa_hubspot_portal_id')); ?>",
    formId: "<?php echo esc_js(get_option('x0pa_hubspot_pdf_form_id')); ?>",
    target: "#hubspot-pdf-form"
});
</script>

<?php
get_footer();
?>
```

---

## Additional Resources

### WordPress Codex References
- [wp_enqueue_script()](https://developer.wordpress.org/reference/functions/wp_enqueue_script/)
- [wp_localize_script()](https://developer.wordpress.org/reference/functions/wp_localize_script/)
- [Script Loading Best Practices](https://developer.wordpress.org/themes/basics/including-css-javascript/)

### HubSpot Documentation
- [Forms API Reference](https://legacydocs.hubspot.com/docs/methods/forms/forms_overview)
- [Form Callbacks](https://legacydocs.hubspot.com/docs/methods/forms/advanced_form_options)

### Browser API Documentation
- [Intersection Observer API](https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API)
- [Fetch API](https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API)
- [Cookies API](https://developer.mozilla.org/en-US/docs/Web/API/Document/cookie)

---

## Support & Maintenance

For issues or questions:
1. Check browser console for error messages
2. Verify HubSpot API is loaded
3. Confirm HTML structure matches requirements
4. Test in debug mode (see Debugging section)
5. Check WordPress admin settings for API keys

**Plugin Version:** 1.0.0
**Last Updated:** January 2025
