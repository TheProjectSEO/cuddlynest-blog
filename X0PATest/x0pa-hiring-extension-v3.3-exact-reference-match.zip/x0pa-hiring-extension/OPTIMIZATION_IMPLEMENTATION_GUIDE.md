# X0PA Hiring Extension - Optimization Implementation Guide

**Quick Start:** Step-by-step guide to implement performance optimizations

---

## Prerequisites

Before implementing optimizations:

✅ **Backup everything:**
```bash
# Backup database
wp db export backup-$(date +%Y%m%d).sql

# Backup plugin files
tar -czf x0pa-hiring-extension-backup-$(date +%Y%m%d).tar.gz x0pa-hiring-extension/

# Or use Git
git add -A
git commit -m "Backup before optimization"
git tag "pre-optimization-backup"
```

✅ **Requirements:**
- WordPress 5.8+
- PHP 7.4+ (recommended: PHP 8.0+)
- MySQL 5.7+ or MariaDB 10.3+
- WP-CLI installed (optional but recommended)

---

## Implementation Steps

### Phase 1: Core PHP Optimizations (15 minutes)

#### Step 1.1: Replace Autoloader

```bash
cd /path/to/wp-content/plugins/x0pa-hiring-extension

# Backup original
cp includes/class-autoloader.php includes/class-autoloader-original.php

# Replace with optimized version
cp includes/class-autoloader-optimized.php includes/class-autoloader.php
```

**Verify:**
```bash
# Check PHP syntax
php -l includes/class-autoloader.php

# Should output: No syntax errors detected
```

#### Step 1.2: Replace Internal Linking Engine

```bash
# Backup original
cp includes/core/class-internal-linking.php includes/core/class-internal-linking-original.php

# Replace with optimized
cp includes/core/class-internal-linking-optimized.php includes/core/class-internal-linking.php
```

**Verify:**
```bash
php -l includes/core/class-internal-linking.php
```

#### Step 1.3: Clear All Caches

```bash
# Method 1: Using WP-CLI
wp cache flush
wp transient delete --all

# Method 2: Via WordPress admin
# Navigate to: Tools > Site Health > Clear Cache
# Or use your caching plugin's clear cache function

# Method 3: Programmatically
wp eval 'wp_cache_flush(); delete_expired_transients();'
```

**Verify:**
```bash
# Check if optimization is active
wp eval 'echo X0PA_Autoloader::get_loaded_count();'
# Should show number of loaded classes
```

---

### Phase 2: JavaScript Optimizations (10 minutes)

#### Step 2.1: Replace Main JavaScript

```bash
# Backup original
cp includes/assets/js/hiring-script.js includes/assets/js/hiring-script-original.js

# Replace with optimized
cp includes/assets/js/hiring-script-optimized.js includes/assets/js/hiring-script.js
```

#### Step 2.2: Create Minified Versions

**Option A: Using online tools**
1. Copy content of `hiring-script-optimized.js`
2. Visit: https://javascript-minifier.com/
3. Paste code and minify
4. Save as `hiring-script.min.js`

**Option B: Using Node.js (recommended)**
```bash
# Install terser globally
npm install -g terser

# Minify all JS files
terser includes/assets/js/hiring-script.js \
  --compress --mangle \
  --output includes/assets/js/hiring-script.min.js

terser includes/assets/js/hubspot-pdf-gate.js \
  --compress --mangle \
  --output includes/assets/js/hubspot-pdf-gate.min.js

terser includes/assets/js/hubspot-newsletter.js \
  --compress --mangle \
  --output includes/assets/js/hubspot-newsletter.min.js
```

**Option C: Using WP-CLI**
```bash
wp plugin install autoptimize --activate
# Configure via Settings > Autoptimize
```

#### Step 2.3: Update Script Enqueue to Use Minified Files

Edit your main plugin file or enqueue file:

```php
// BEFORE
wp_enqueue_script('x0pa-hiring-script',
    plugins_url('assets/js/hiring-script.js', __FILE__),
    array(), '1.0.0', true
);

// AFTER
$suffix = (defined('SCRIPT_DEBUG') && SCRIPT_DEBUG) ? '' : '.min';
wp_enqueue_script('x0pa-hiring-script',
    plugins_url("assets/js/hiring-script{$suffix}.js", __FILE__),
    array(), '1.1.0', array(
        'strategy' => 'defer',
        'in_footer' => true
    )
);
```

---

### Phase 3: Database Optimizations (5 minutes)

#### Step 3.1: Add Performance Indexes

```bash
# Connect to database
wp db cli

# Or use phpMyAdmin / MySQL client
```

Run these queries:

```sql
-- Check current indexes
SHOW INDEX FROM wp_postmeta WHERE Key_name LIKE '%x0pa%';

-- Add optimized indexes
ALTER TABLE wp_postmeta
ADD INDEX idx_x0pa_page_type (meta_key(50), meta_value(50), post_id);

ALTER TABLE wp_postmeta
ADD INDEX idx_x0pa_job_title (meta_key(50), post_id);

ALTER TABLE wp_posts
ADD INDEX idx_x0pa_hiring_status (post_type(20), post_status(20));

-- Verify indexes were created
SHOW INDEX FROM wp_postmeta WHERE Key_name LIKE 'idx_x0pa%';
```

**Expected output:**
```
+------------+----------------------+
| Table      | Key_name             |
+------------+----------------------+
| wp_postmeta| idx_x0pa_page_type   |
| wp_postmeta| idx_x0pa_job_title   |
| wp_posts   | idx_x0pa_hiring_status|
+------------+----------------------+
```

---

### Phase 4: Caching Configuration (10 minutes)

#### Step 4.1: Enable Object Caching (Optional but Recommended)

**Using Redis:**

```bash
# Install Redis
sudo apt-get install redis-server

# Install Redis plugin
wp plugin install redis-cache --activate

# Enable Redis
wp redis enable
```

**Using Memcached:**

```bash
# Install Memcached
sudo apt-get install memcached

# Install plugin
wp plugin install memcached --activate
```

#### Step 4.2: Configure Cache Settings

Add to `wp-config.php`:

```php
// Enable WordPress object cache
define('WP_CACHE', true);

// Cache duration for X0PA plugin (in seconds)
define('X0PA_CACHE_DURATION', 12 * HOUR_IN_SECONDS);

// Disable cache for development
if (defined('WP_DEBUG') && WP_DEBUG) {
    define('X0PA_DISABLE_CACHE', true);
}
```

#### Step 4.3: Set Up Cache Invalidation Hooks

Add to your theme's `functions.php` or plugin:

```php
/**
 * Clear X0PA caches when posts are updated
 */
add_action('save_post_x0pa_hiring_page', function($post_id) {
    // Clear related caches
    X0PA_Internal_Linking::clear_post_cache($post_id);
    X0PA_Hub_Page::clear_cache();

    // Clear full page cache if using plugin
    if (function_exists('rocket_clean_post')) {
        rocket_clean_post($post_id);
    }
}, 10, 1);

/**
 * Clear caches on bulk operations
 */
add_action('x0pa_bulk_operation_complete', function() {
    X0PA_Internal_Linking::clear_all_caches();
    X0PA_Hub_Page::clear_cache();
    wp_cache_flush();
});
```

---

### Phase 5: Testing & Validation (20 minutes)

#### Step 5.1: Functional Testing

**Test Checklist:**

```bash
# 1. Test Custom Post Type
wp post list --post_type=x0pa_hiring_page --format=count
# Should show number of hiring pages

# 2. Test Internal Linking
# Visit any hiring page and check "Related Resources" section
# Should show 4 related pages with similarity scores

# 3. Test Hub Page
# Visit: /hiring/
# Should load with all job titles grouped

# 4. Test CSV Upload
# Go to: Admin > Hiring Pages > Upload CSV
# Upload a test CSV and verify it processes

# 5. Test Schemas
# View page source of any hiring page
# Search for: <script type="application/ld+json">
# Verify WebPage, FAQ, and Author schemas are present
```

#### Step 5.2: Performance Testing

**Using Query Monitor:**

```bash
# Install Query Monitor
wp plugin install query-monitor --activate
```

Visit hiring pages and check:
- Total database queries should be < 10
- Query time should be < 50ms
- Peak memory should be < 20MB

**Using Chrome DevTools:**

1. Open DevTools (F12)
2. Go to Lighthouse tab
3. Run performance audit
4. Target scores:
   - Performance: > 85
   - Best Practices: > 90
   - SEO: > 95

**Command Line Performance Test:**

```bash
# Test page load time
time curl -s -o /dev/null -w "%{time_total}\n" https://yoursite.com/hiring/accountant-interview-questions/

# Should be < 2 seconds
```

#### Step 5.3: Cache Effectiveness Test

```bash
# Test 1: Cold cache (first load)
wp transient delete --all
time curl -s https://yoursite.com/hiring/ > /dev/null

# Test 2: Warm cache (second load)
time curl -s https://yoursite.com/hiring/ > /dev/null

# Second load should be significantly faster (70-90% improvement)
```

---

### Phase 6: Monitoring Setup (5 minutes)

#### Step 6.1: Enable Performance Monitoring

Add to `wp-config.php`:

```php
// Enable Query Monitor
define('QM_ENABLE_CAPS_PANEL', true);
define('QM_ENABLE_STACK_TRACES', true);

// Log slow queries
define('SAVEQUERIES', true);

// Log errors to file
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

#### Step 6.2: Create Performance Dashboard Widget

Add to `functions.php`:

```php
/**
 * X0PA Performance Dashboard Widget
 */
add_action('wp_dashboard_setup', function() {
    wp_add_dashboard_widget(
        'x0pa_performance_widget',
        'X0PA Performance Metrics',
        'x0pa_performance_dashboard_widget'
    );
});

function x0pa_performance_dashboard_widget() {
    global $wpdb;

    // Get cache statistics
    $cache_hits = wp_cache_get('hits', X0PA_Internal_Linking::CACHE_GROUP) ?: 0;
    $cache_misses = wp_cache_get('misses', X0PA_Internal_Linking::CACHE_GROUP) ?: 0;
    $cache_hit_rate = $cache_hits + $cache_misses > 0
        ? round(($cache_hits / ($cache_hits + $cache_misses)) * 100, 1)
        : 0;

    // Get database statistics
    $post_count = wp_count_posts('x0pa_hiring_page')->publish;

    // Get average page load time (from transient)
    $avg_load_time = get_transient('x0pa_avg_load_time') ?: 'N/A';

    ?>
    <div class="x0pa-performance-stats">
        <h4>Cache Performance</h4>
        <p>
            <strong>Hit Rate:</strong> <?php echo $cache_hit_rate; ?>%<br>
            <strong>Hits:</strong> <?php echo number_format($cache_hits); ?><br>
            <strong>Misses:</strong> <?php echo number_format($cache_misses); ?>
        </p>

        <h4>Database</h4>
        <p>
            <strong>Total Pages:</strong> <?php echo number_format($post_count); ?><br>
            <strong>Avg Load Time:</strong> <?php echo $avg_load_time; ?>s
        </p>

        <p>
            <a href="<?php echo admin_url('admin.php?page=x0pa-clear-cache'); ?>"
               class="button">Clear Caches</a>
        </p>
    </div>
    <?php
}
```

---

## Troubleshooting

### Issue: "White Screen of Death" after replacing files

**Solution:**

```bash
# 1. Enable debug mode
# Add to wp-config.php:
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', true);

# 2. Check error log
tail -f wp-content/debug.log

# 3. Rollback to original files
cp includes/class-autoloader-original.php includes/class-autoloader.php
```

### Issue: "Call to undefined function" error

**Cause:** PHP version incompatibility

**Solution:**

```bash
# Check PHP version
php -v

# If < 7.4, remove type hints:
# Find: function get_related_pages(string $title, int $id): array
# Replace: function get_related_pages($title, $id)
```

### Issue: Related pages not showing after optimization

**Solution:**

```bash
# Clear all caches
wp transient delete --all
wp cache flush

# Regenerate cache
wp eval 'X0PA_Internal_Linking::clear_all_caches();'

# Visit a few hiring pages to warm up cache
```

### Issue: Database queries still high

**Solution:**

```bash
# 1. Verify indexes are created
wp db query "SHOW INDEX FROM wp_postmeta WHERE Key_name LIKE 'idx_x0pa%';"

# 2. Enable query logging
# Add to wp-config.php:
define('SAVEQUERIES', true);

# 3. Check which queries are slow
# Install Query Monitor and check slow queries
```

### Issue: JavaScript errors in console

**Solution:**

```bash
# 1. Clear browser cache
# 2. Check if minified version is being loaded
# 3. If errors persist, use non-minified version:

# In wp-config.php:
define('SCRIPT_DEBUG', true);
```

---

## Rollback Procedures

### Complete Rollback

```bash
cd /path/to/wp-content/plugins/x0pa-hiring-extension

# Restore all original files
cp includes/class-autoloader-original.php includes/class-autoloader.php
cp includes/core/class-internal-linking-original.php includes/core/class-internal-linking.php
cp includes/assets/js/hiring-script-original.js includes/assets/js/hiring-script.js

# Clear all caches
wp cache flush
wp transient delete --all

# Remove indexes (optional)
wp db query "
    ALTER TABLE wp_postmeta DROP INDEX idx_x0pa_page_type;
    ALTER TABLE wp_postmeta DROP INDEX idx_x0pa_job_title;
    ALTER TABLE wp_posts DROP INDEX idx_x0pa_hiring_status;
"
```

### Selective Rollback

**Rollback only PHP optimizations:**
```bash
cp includes/class-autoloader-original.php includes/class-autoloader.php
wp cache flush
```

**Rollback only JavaScript:**
```bash
cp includes/assets/js/hiring-script-original.js includes/assets/js/hiring-script.js
# Clear browser cache
```

**Rollback only database indexes:**
```bash
wp db query "ALTER TABLE wp_postmeta DROP INDEX idx_x0pa_page_type;"
```

---

## Performance Monitoring Commands

### Check Cache Performance

```bash
# Get cache statistics
wp eval '
    $hits = wp_cache_get("hits", "x0pa_internal_links");
    $misses = wp_cache_get("misses", "x0pa_internal_links");
    echo "Hits: $hits, Misses: $misses\n";
'
```

### Check Database Performance

```bash
# Count queries on a page load
wp eval '
    global $wpdb;
    $wpdb->queries = array();
    define("SAVEQUERIES", true);

    // Simulate page load
    query_posts(array("post_type" => "x0pa_hiring_page", "p" => 123));

    echo "Total queries: " . count($wpdb->queries) . "\n";
    foreach ($wpdb->queries as $query) {
        echo $query[1] . "s - " . $query[0] . "\n";
    }
'
```

### Monitor Page Load Times

```bash
# Create a monitoring script
cat > monitor-performance.sh << 'EOF'
#!/bin/bash
URL="https://yoursite.com/hiring/accountant-interview-questions/"

echo "Monitoring page load times..."
for i in {1..10}; do
    time=$(curl -s -o /dev/null -w "%{time_total}" "$URL")
    echo "Load $i: ${time}s"
    sleep 1
done
EOF

chmod +x monitor-performance.sh
./monitor-performance.sh
```

---

## Success Metrics

After implementation, you should see:

✅ **Page Load Metrics:**
- First Contentful Paint: < 1.5s
- Largest Contentful Paint: < 2.5s
- Time to Interactive: < 3.0s

✅ **Database Metrics:**
- Queries per page: < 10
- Query execution time: < 50ms

✅ **JavaScript Metrics:**
- Execution time: < 120ms
- Long tasks: 0

✅ **Cache Metrics:**
- Hit rate: > 70% (after warm-up)

✅ **Resource Metrics:**
- Total page size: < 200KB
- JavaScript size: < 45KB

---

## Next Steps

After successful implementation:

1. **Monitor for 1 week** - Watch for any issues
2. **Collect metrics** - Compare before/after performance
3. **User feedback** - Ask users if they notice improvements
4. **Further optimize** - Implement recommendations from report
5. **Document learnings** - Note what worked best

---

## Support

If you encounter issues:

1. Check `wp-content/debug.log` for PHP errors
2. Check browser console for JavaScript errors
3. Use Query Monitor to debug database queries
4. Compare original vs optimized file differences
5. Rollback if critical issues occur

---

**Last Updated:** January 2025
**Version:** 1.1.0 (Optimized)
