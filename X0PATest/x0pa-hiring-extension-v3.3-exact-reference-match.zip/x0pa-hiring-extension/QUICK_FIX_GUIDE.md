# Quick Fix Guide: Interview Questions Not Showing

## The Problem
Page shows "0 Marketing Manager Interview Questions" instead of displaying the actual questions from your CSV file.

## The Fix (3 Simple Steps)

### Step 1: Enable Debug Mode
Edit your `wp-config.php` file and add these lines near the top:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

### Step 2: Re-Upload Your CSV
1. Go to: **WordPress Admin → X0PA Hiring → Bulk Import**
2. Select: **Interview Questions**
3. Click: **Choose File** and select your `comprehensive-interview-questions.csv`
4. Click: **Upload and Process**

### Step 3: Check the Results
Visit your interview questions page. It should now show:
- ✅ Correct number of questions (e.g., "29 Marketing Manager Interview Questions")
- ✅ All question sections rendered
- ✅ "What to Listen For" boxes visible

## Still Not Working?

### Quick Debug
Upload `debug-interview-questions.php` to your WordPress root and visit:
```
https://yoursite.com/debug-interview-questions.php
```

Look for errors in the output. **Delete the file immediately after viewing.**

### Check Debug Log
View the file: `/wp-content/debug.log`

Look for lines starting with:
- `X0PA CSV Import` - Shows CSV processing status
- `X0PA Debug` - Shows page rendering status

### Common Issues

**1. Still shows 0 questions after re-import**
- Clear your browser cache
- Try a different browser
- Check debug.log for errors

**2. Some questions missing**
- Check your CSV file has valid JSON in the questions columns
- Use https://jsonlint.com/ to validate the JSON
- Make sure CSV is UTF-8 encoded

**3. Sections not rendering**
- Verify CSV column names are exact: `section_1_id`, `section_1_title`, `section_1_questions_json`
- Check for typos in column headers
- Ensure JSON is properly escaped (use `""` for quotes inside JSON)

## What Was Fixed?

The template was looking for data in the wrong format. The bulk processor stores:

```
section_1 → {id, title, questions}
```

But the template was looking for:
```
section_1_id, section_1_title, section_1_questions_json
```

Now they match!

## Need More Help?

See the full documentation: `DEBUG_INTERVIEW_QUESTIONS_FIX.md`

## After Fixing

Once everything works:
1. Turn off debug mode in `wp-config.php` (change `true` to `false`)
2. Delete `debug-interview-questions.php`
3. Clear `/wp-content/debug.log`
