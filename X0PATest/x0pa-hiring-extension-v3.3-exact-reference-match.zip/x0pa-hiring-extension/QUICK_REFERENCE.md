# X0PA Hiring Extension - Quick Reference Card

**Version:** 1.0.0 | **Date:** November 17, 2024

---

## 🚀 Quick Start (5 Minutes)

### 1. Load Autoloader

```php
// x0pa-hiring-extension.php (main plugin file)
require_once plugin_dir_path(__FILE__) . 'includes/class-autoloader.php';
```

### 2. Basic Template

```php
<?php
// single-x0pa_hiring_page.php
get_header();

global $post;
$job_title = get_post_meta($post->ID, '_x0pa_job_title', true);
$page_type = get_post_meta($post->ID, '_x0pa_page_type', true);
$content_json = get_post_meta($post->ID, '_x0pa_content_json', true);

// Generate components
$seo_meta = X0PA_SEO_Meta::generate($post, $content_json);
?>

<head>
    <?php
    X0PA_WebPage_Schema::output_schema($post);
    X0PA_Author_Schema::output_schema();
    if ($page_type === 'interview-questions') {
        X0PA_FAQ_Schema::output_schema($content_json, 3);
    }
    wp_head();
    ?>
</head>

<body>
    <?php echo X0PA_Hero_Generator::generate($post, $seo_meta); ?>
    <!-- Your content here -->
    <?php wp_footer(); ?>
</body>
```

---

## 📦 Components Cheat Sheet

### Schemas (in `<head>`)

```php
// WebPage Schema (always)
X0PA_WebPage_Schema::output_schema($post);

// Author Schema (always)
X0PA_Author_Schema::output_schema();

// FAQ Schema (interview-questions only, if ≥3 Q&A)
X0PA_FAQ_Schema::output_schema($content_json, 3);
```

### Internal Linking

```php
// Get 4 related pages (same type)
$related = X0PA_Internal_Linking::get_related_pages(
    $job_title,      // e.g., "Software Engineer"
    $page_type,      // e.g., "interview-questions"
    $post->ID,       // Current post ID (EXCLUDED from results)
    4                // Limit
);

// Render as HTML
echo X0PA_Internal_Linking::render_related_pages($related, 'Related Resources');
```

### Hub Page

```php
// Render complete hub page
echo X0PA_Hub_Page::render_hub_page();

// Get hub page URL
$url = X0PA_Hub_Page::get_hub_page_url();

// Get statistics
$stats = X0PA_Hub_Page::get_statistics();
// Returns: total_job_titles, total_interview_questions, total_job_descriptions, complete_sets
```

### Content Generators

```php
// SEO Meta
$seo_meta = X0PA_SEO_Meta::generate($post, $content_json);
// Returns: title, description, og:*, twitter:*, reading_time, word_count

// Hero Section
echo X0PA_Hero_Generator::generate($post, $seo_meta);

// Table of Contents
$toc = X0PA_TOC_Generator::generate_from_content($content_json);
echo X0PA_TOC_Generator::render_jump_links($toc);
echo X0PA_TOC_Generator::generate_scrollspy_script($toc);

// Interview Overview (interview-questions only)
echo X0PA_Interview_Overview::generate($content_json, $job_title);
```

---

## 🔧 Common Tasks

### Clear Cache

```php
// Clear internal linking cache
X0PA_Internal_Linking::clear_all_caches();

// Clear hub page cache
X0PA_Hub_Page::clear_cache();

// Clear specific post cache
X0PA_Internal_Linking::clear_post_cache($post_id);
```

### Validate Schemas

```php
// Output schema for validation
echo X0PA_WebPage_Schema::generate($post);
// Copy output to: https://search.google.com/test/rich-results
```

### Get Reading Time

```php
$seo_meta = X0PA_SEO_Meta::generate($post, $content);
echo X0PA_SEO_Meta::format_reading_time($seo_meta['reading_time']);
// Output: "5 min read"
```

---

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| Schemas not showing | Check if `wp_head()` is called |
| Internal links not working | Clear cache: `X0PA_Internal_Linking::clear_all_caches()` |
| Hub page 404 | Re-save permalinks in WordPress admin |
| PHP errors | Check `/wp-content/debug.log` |
| Performance slow | Enable object caching (Redis/Memcached) |

---

## 📊 Performance Targets

| Operation | Target | Cache |
|-----------|--------|-------|
| Schema generation | < 50ms | No |
| Internal linking | < 10ms | Yes (12h) |
| Internal linking | < 500ms | No |
| TOC generation | < 100ms | No |
| Hub page render | < 300ms | Yes (6h) |

---

## 📚 Documentation

- **INTEGRATION_GUIDE.md** - Complete integration instructions
- **TESTING_GUIDE.md** - Unit tests and validation
- **PHP_COMPONENTS_SUMMARY.md** - Component overview
- **DEPLOYMENT_CHECKLIST.md** - Production deployment
- **DELIVERY_SUMMARY.md** - What was delivered

---

## 🔒 Security Checklist

- ✅ All output escaped (esc_html, esc_url, esc_attr)
- ✅ Uses WordPress meta API (prepared statements)
- ✅ Input validation on all parameters
- ✅ No hardcoded credentials

---

## ⚡ Quick Commands

```bash
# Run unit tests
wp eval-file tests/unit-tests.php

# Create test page
wp post create --post_type=x0pa_hiring_page --post_title="Test" --post_status=publish

# Clear all caches
wp eval "X0PA_Internal_Linking::clear_all_caches(); X0PA_Hub_Page::clear_cache();"

# Output schema for validation
wp eval "echo X0PA_WebPage_Schema::generate(get_post(123));"
```

---

## 💡 Pro Tips

1. **Always exclude current page** - Internal linking does this automatically
2. **Use caching** - 95% faster on second load
3. **Validate schemas** - Use Google Rich Results Test regularly
4. **Monitor performance** - Run benchmarks monthly
5. **Clear cache on update** - Happens automatically on post save

---

## 🎯 Key Methods

### Most Used

```php
// 1. Generate SEO metadata
$seo_meta = X0PA_SEO_Meta::generate($post, $content);

// 2. Get related pages
$related = X0PA_Internal_Linking::get_related_pages($job_title, $page_type, $post->ID, 4);

// 3. Output schemas
X0PA_WebPage_Schema::output_schema($post);

// 4. Generate hero
echo X0PA_Hero_Generator::generate($post, $seo_meta);

// 5. Render hub page
echo X0PA_Hub_Page::render_hub_page();
```

---

**Need Help?** Check the comprehensive guides:
- Integration: `INTEGRATION_GUIDE.md`
- Testing: `TESTING_GUIDE.md`
- Overview: `PHP_COMPONENTS_SUMMARY.md`

---

**Version:** 1.0.0 | **Status:** Production Ready ✅
