# Quick Start: Tailwind CSS Styling
## X0PA Hiring Extension - For Developers

**⏱️ 5-Minute Setup Guide**

---

## Step 1: Include Tailwind in Your Template

Add to `<head>` section of any PHP template:

```php
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your Page Title</title>

  <!-- ✅ REQUIRED: Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com?plugins=forms"></script>

  <!-- ✅ REQUIRED: Custom Colors -->
  <?php include X0PA_HIRING_PLUGIN_DIR . 'includes/config/tailwind-config.php'; ?>

  <!-- ✅ REQUIRED: Component Styles -->
  <?php include X0PA_HIRING_PLUGIN_DIR . 'includes/assets/css/styles.php'; ?>
</head>
<body class="bg-white">
  <!-- Your content here -->
</body>
</html>
```

---

## Step 2: Use Basic Layout Structure

```html
<div class="hiring">
  <!-- Hero Section (Full-width blue background) -->
  <div class="hiring__hero">
    <div class="hiring__hero-wrapper">
      <div class="hiring__hero-content">
        <h1 class="hiring__hero-title">Your Page Title</h1>
        <p class="hiring__hero-description">Your description</p>
      </div>
    </div>
  </div>

  <!-- 3-Column Layout -->
  <div class="hiring__layout">
    <!-- Left: TOC (hidden on mobile) -->
    <aside class="hiring__layout-sidebar-left">
      <nav class="jump-links">
        <!-- TOC content -->
      </nav>
    </aside>

    <!-- Center: Main Content -->
    <main class="hiring__layout-content">
      <!-- Your content sections -->
    </main>

    <!-- Right: Author/Resources -->
    <aside class="hiring__layout-sidebar-right">
      <!-- Sidebar content -->
    </aside>
  </div>
</div>
```

---

## Step 3: Add Content Sections

```html
<section id="section-id" class="content-section">
  <!-- Section Title -->
  <div class="content-section__title">
    Section Title Here
  </div>

  <!-- Section Body -->
  <div class="content-section__body">
    <!-- Content items go here -->
  </div>
</section>
```

---

## Step 4: Add Questions (Interview Questions Pages)

```html
<article class="content-item">
  <!-- Question Heading (h3 required for schema) -->
  <h3 class="content-item__title">
    What is your question text here?
  </h3>

  <!-- Answer Box -->
  <div class="content-item__box">
    <h4 class="content-item__box-title">What to Listen For:</h4>

    <!-- Answer List (ul required for schema) -->
    <ul class="content-item__box-list">
      <li class="content-item__box-list-item">Point 1</li>
      <li class="content-item__box-list-item">Point 2</li>
      <li class="content-item__box-list-item">Point 3</li>
    </ul>
  </div>
</article>
```

---

## Step 5: Add Job Description Template Box

```html
<article class="content-item">
  <div class="job-description-section">
    <div class="job-description-section__content">
      • Responsibility 1
      • Responsibility 2
      • Responsibility 3
    </div>
  </div>
</article>
```

---

## Custom Colors (Use Anywhere)

```html
<!-- Backgrounds -->
<div class="bg-primary">...</div>      <!-- Main blue -->
<div class="bg-blue-dark">...</div>    <!-- Dark blue -->
<div class="bg-accent">...</div>       <!-- Orange -->

<!-- Text -->
<p class="text-dark">...</p>           <!-- Dark text -->
<p class="text-gray">...</p>           <!-- Gray text -->
<a class="text-primary">...</a>        <!-- Blue link -->

<!-- Borders -->
<div class="border-gray">...</div>     <!-- Gray border -->
<div class="border-primary">...</div>  <!-- Blue border -->

<!-- Hover States -->
<button class="bg-primary hover:bg-navy">Click Me</button>
<a class="text-gray hover:text-primary">Link</a>
```

---

## Responsive Patterns (Mobile-First)

```html
<!-- Typography: Mobile → Desktop -->
<h1 class="text-3xl sm:text-4xl md:text-5xl">Title</h1>
<p class="text-base sm:text-lg">Body text</p>
<span class="text-xs sm:text-sm">Small text</span>

<!-- Spacing: Mobile → Desktop -->
<div class="p-4 sm:p-6 lg:p-8">Padding scales</div>
<div class="gap-6 sm:gap-8">Gap scales</div>

<!-- Layout: Stack → Row -->
<div class="flex flex-col lg:flex-row">
  <div>Item 1</div>
  <div>Item 2</div>
</div>

<!-- Visibility: Hide on mobile, show on desktop -->
<aside class="hidden lg:block">Desktop only</aside>

<!-- Visibility: Show on mobile, hide on desktop -->
<button class="block lg:hidden">Mobile only</button>
```

---

## Common Components (Copy-Paste Ready)

### Author Card

```html
<div class="bg-white border border-gray rounded-lg p-3 flex items-start gap-4 shadow-sm mb-6">
  <img src="path/to/image.jpg" alt="Author Name"
       class="w-16 h-16 rounded-full flex-shrink-0 object-cover">
  <div class="flex-1">
    <div class="font-bold text-dark mb-1">Author Name</div>
    <div class="text-sm text-gray mb-2">Author Title</div>
    <a href="https://linkedin.com/..." class="text-primary hover:text-navy">
      LinkedIn →
    </a>
  </div>
</div>
```

### PDF Download Button

```html
<button id="pdf-download-btn"
        class="bg-primary text-white px-4 py-2.5 rounded-lg font-semibold
               transition-all duration-200 hover:bg-navy flex gap-2 cursor-pointer w-full">
  <span class="text-sm">Download Interview Questions PDF</span>
</button>
```

### Resource Links Card

```html
<div class="bg-white border border-gray rounded-lg p-6">
  <h3 class="text-lg font-bold text-dark mb-4">More Templates</h3>

  <ul class="flex flex-col gap-2 mb-4">
    <li class="text-sm text-gray hover:text-primary transition-colors">
      <a href="#">Template Link 1</a>
    </li>
    <li class="text-sm text-gray hover:text-primary transition-colors">
      <a href="#">Template Link 2</a>
    </li>
  </ul>

  <a href="/hiring/" class="text-primary hover:text-navy font-semibold text-sm">
    Browse All Templates →
  </a>
</div>
```

### CTA Product Card

```html
<div class="bg-blue-dark py-8 sm:py-12 px-4 sm:px-8 rounded-lg">
  <div class="max-w-4xl mx-auto text-center">
    <h2 class="text-2xl sm:text-3xl font-bold text-white mb-4">
      Download Free Interview Questions
    </h2>
    <p class="text-white text-base sm:text-lg mb-6 leading-relaxed">
      Get expert-crafted questions for your hiring process.
    </p>
    <button class="bg-accent text-white px-6 py-3 rounded-lg font-semibold
                   hover:bg-opacity-90 transition-all">
      Download PDF
    </button>
  </div>
</div>
```

---

## Breakpoints Reference

| Screen | Width | Prefix | Use For |
|--------|-------|--------|---------|
| Mobile | < 640px | (none) | Base styles |
| SM | 640px+ | `sm:` | Large phones |
| MD | 768px+ | `md:` | Tablets |
| LG | 1024px+ | `lg:` | Desktop |
| XL | 1280px+ | `xl:` | Large desktop |

**Example:**
```html
<!-- Mobile: 1 column, Desktop: 3 columns -->
<div class="grid grid-cols-1 lg:grid-cols-3">
  <div>Col 1</div>
  <div>Col 2</div>
  <div>Col 3</div>
</div>
```

---

## Testing Your Changes

### 1. Mobile First (375px)

```bash
# Chrome DevTools
1. Open Chrome DevTools (F12)
2. Toggle Device Toolbar (Ctrl+Shift+M)
3. Select "iPhone SE" or set custom 375px width
4. Verify:
   ✓ All text readable
   ✓ No horizontal scroll
   ✓ Buttons at least 44px tall
```

### 2. Desktop (1024px+)

```bash
# Chrome DevTools
1. Set viewport to 1280px width
2. Verify:
   ✓ 3-column layout displays
   ✓ Sticky sidebars work
   ✓ Hover states function
```

---

## Common Issues & Fixes

### Issue: Tailwind classes not working

**Fix:**
```html
<!-- ✅ Correct: Include CDN -->
<script src="https://cdn.tailwindcss.com?plugins=forms"></script>

<!-- ❌ Wrong: Missing CDN -->
<link rel="stylesheet" href="tailwind.css">
```

### Issue: Custom colors not working

**Fix:**
```php
<!-- ✅ Correct: Include config -->
<?php include X0PA_HIRING_PLUGIN_DIR . 'includes/config/tailwind-config.php'; ?>

<!-- ❌ Wrong: Missing config -->
<div class="bg-primary">...</div> <!-- Won't work without config -->
```

### Issue: Component classes not applied

**Fix:**
```php
<!-- ✅ Correct: Include styles -->
<?php include X0PA_HIRING_PLUGIN_DIR . 'includes/assets/css/styles.php'; ?>

<!-- ❌ Wrong: Missing styles -->
<div class="hiring__hero">...</div> <!-- Won't work without styles -->
```

### Issue: Layout not responsive

**Fix:**
```html
<!-- ✅ Correct: Mobile-first classes -->
<div class="text-3xl sm:text-4xl md:text-5xl">Title</div>

<!-- ❌ Wrong: Only desktop classes -->
<div class="text-5xl">Title</div> <!-- Too large on mobile -->
```

---

## Need More Help?

### 📖 Full Documentation
- `TAILWIND_STYLING_GUIDE.md` - Complete styling guide
- `RESPONSIVE_DESIGN_NOTES.md` - Responsive patterns

### 🎨 Color Reference
- Primary: `#173b8c` (blue)
- Dark: `#17141c` (text)
- Accent: `#f59e0a` (orange)
- Navy: `#172b69` (dark blue)
- Gray: `#a3a1a8` (border)
- Blue-dark: `#171f54` (backgrounds)

### 📐 Spacing Scale (Tailwind default)
- `p-1` = 4px
- `p-2` = 8px
- `p-3` = 12px
- `p-4` = 16px
- `p-6` = 24px
- `p-8` = 32px

### 🎯 Class Cheat Sheet
```
Padding:    p-4, px-6, py-8
Margin:     m-4, mx-auto, my-6
Gap:        gap-4, gap-x-6, gap-y-8
Text:       text-base, text-lg, text-xl
Font:       font-normal, font-semibold, font-bold
Border:     border, border-2, border-gray
Rounded:    rounded, rounded-md, rounded-lg
```

---

**🚀 You're ready to build!**

Start with the layout structure, add sections, apply component classes, and test responsively.

**Questions?** Check the full documentation files listed above.

---

**Last Updated:** November 17, 2025
