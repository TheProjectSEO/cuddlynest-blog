# X0PA Hiring Extension WordPress Plugin

A WordPress plugin to create and manage hiring pages (interview questions & job descriptions) with automated schema, internal linking, and hub page generation.

## Features

- **Custom Post Type**: Dedicated `x0pa_hiring_page` post type for hiring content
- **Dual Page Types**: Support for Interview Questions and Job Description pages
- **CSV Bulk Upload**: Import multiple pages at once via CSV files
- **Custom URL Structure**: Clean URLs like `/hiring/accountant-interview-questions/`
- **Hub Page**: Automatically generated and maintained at `/hiring/`
- **Admin Interface**: Easy-to-use admin panel for uploading and managing pages
- **Meta Data Storage**: JSON-based content storage for flexibility
- **Automatic Linking**: Hub page automatically links to all hiring pages

## Installation

### Method 1: WordPress Admin Panel

1. Download the `x0pa-hiring-extension` folder
2. Compress it into a ZIP file
3. Go to WordPress Admin → Plugins → Add New
4. Click "Upload Plugin" and select the ZIP file
5. Click "Install Now"
6. Activate the plugin

### Method 2: FTP Upload

1. Download the `x0pa-hiring-extension` folder
2. Upload it to `/wp-content/plugins/` directory via FTP
3. Go to WordPress Admin → Plugins
4. Find "X0PA Hiring Extension" and click "Activate"

### Method 3: Local Development

1. Copy the `x0pa-hiring-extension` folder to your WordPress plugins directory:
   ```
   cp -r x0pa-hiring-extension /path/to/wordpress/wp-content/plugins/
   ```
2. Activate the plugin through the WordPress admin panel

## What Happens on Activation

When you activate the plugin:

1. Custom post type `x0pa_hiring_page` is registered
2. Custom URL rewrite rules are added
3. A hub page is created at `/hiring/`
4. Rewrite rules are flushed to enable custom URLs

## Plugin Structure

```
x0pa-hiring-extension/
├── x0pa-hiring-extension.php      # Main plugin file
├── uninstall.php                  # Cleanup on uninstall
├── README.md                      # This file
├── includes/
│   ├── core/
│   │   ├── class-custom-post-type.php    # CPT registration
│   │   └── class-url-rewrite.php         # URL handling
│   └── admin/
│       ├── class-admin-menu.php          # Admin pages
│       ├── class-csv-uploader.php        # File upload handler
│       ├── class-bulk-processor.php      # CSV processor
│       └── views/
│           ├── upload-form.php           # Upload interface
│           └── page-list.php             # Manage pages
```

## Usage

### Accessing Admin Panel

After activation, you'll find new menu items in WordPress Admin:

1. **Hiring Pages** - Main menu item (shows all hiring pages)
2. **Upload Pages** - Submenu for CSV uploads
3. **Manage Pages** - Submenu for viewing/managing all pages

### Uploading CSV Files

1. Go to **Hiring Pages → Upload Pages**
2. You can upload two types of CSV files:
   - Interview Questions CSV
   - Job Description CSV
3. Select your CSV file(s)
4. Click "Upload CSV Files"

### CSV Format for Interview Questions

**Required columns:**
- `job_title` - The job position name (e.g., "Accountant")
- `last_updated` - Date in YYYY-MM-DD format

**Section columns (repeating pattern):**
- `section_1_id` - Section identifier
- `section_1_title` - Section title
- `section_1_questions_json` - JSON string of questions
- `section_2_id`, `section_2_title`, `section_2_questions_json`, etc.

**Example CSV:**

```csv
job_title,last_updated,section_1_id,section_1_title,section_1_questions_json,section_2_id,section_2_title,section_2_questions_json
Accountant,2025-01-15,general,General Questions,"{""q1"":""Tell us about yourself"",""q2"":""Why accounting?""}",technical,Technical Skills,"{""q1"":""Experience with tax software?"",""q2"":""Explain GAAP principles""}"
Software Engineer,2025-01-15,general,General Questions,"{""q1"":""Tell us about yourself"",""q2"":""Why software engineering?""}",technical,Technical Skills,"{""q1"":""Programming languages?"",""q2"":""Explain OOP concepts""}"
```

### CSV Format for Job Description

**Required column:**
- `job_title` - The job position name

**Optional columns:**
- `last_updated` - Date in YYYY-MM-DD format
- `objectives` - Job objectives
- `responsibilities` - Job responsibilities
- `required_skills` - Required skills
- `preferred_skills` - Preferred skills
- `what_role_does` - What the role does
- `skills_to_look_for` - Skills to look for in candidates

**Example CSV:**

```csv
job_title,last_updated,objectives,responsibilities,required_skills,preferred_skills,what_role_does,skills_to_look_for
Accountant,2025-01-15,"Manage financial records and reporting","Prepare financial statements; Manage accounts payable/receivable","Bachelor's in Accounting; 3+ years experience","CPA certification; SAP experience","Ensures accurate financial reporting","Attention to detail; Analytical thinking"
Software Engineer,2025-01-15,"Develop software solutions","Write clean code; Participate in code reviews","Bachelor's in CS; 2+ years experience","AWS certification; Agile experience","Builds scalable applications","Problem solving; Communication"
```

### Managing Pages

Go to **Hiring Pages → Manage Pages** to:

- View all hiring pages in a table
- Filter by page type (Interview Questions or Job Description)
- See statistics (total pages, breakdown by type)
- Edit individual pages
- Delete pages (single or bulk)
- View the hub page

### URL Structure

The plugin creates the following URL patterns:

- **Hub page**: `yoursite.com/hiring/`
- **Interview Questions**: `yoursite.com/hiring/{job-title-slug}-interview-questions/`
- **Job Description**: `yoursite.com/hiring/{job-title-slug}-job-description/`

Examples:
- `yoursite.com/hiring/accountant-interview-questions/`
- `yoursite.com/hiring/accountant-job-description/`
- `yoursite.com/hiring/software-engineer-interview-questions/`

### Hub Page

The hub page at `/hiring/` is automatically:
- Created on plugin activation
- Updated whenever pages are uploaded
- Organized by job title with links to both Interview Questions and Job Description

You can customize the hub page content by editing it through WordPress admin.

### Editing Individual Pages

1. Go to **Hiring Pages → All Hiring Pages**
2. Click on a page title or "Edit"
3. You can modify:
   - Job Title
   - Page Type
   - Last Updated Date
   - Content JSON

## Meta Fields

Each hiring page stores the following meta data:

- `_x0pa_page_type` - Either "interview-questions" or "job-description"
- `_x0pa_job_title` - The job title (e.g., "Accountant")
- `_x0pa_last_updated` - Date of last update
- `_x0pa_content_json` - JSON-encoded content data

## Technical Details

### Custom Post Type

- **Slug**: `x0pa_hiring_page`
- **Public**: Yes
- **Supports**: Title, Custom Fields
- **Has Archive**: No
- **Menu Icon**: dashicons-portfolio

### Rewrite Rules

Custom rewrite rules are registered to handle the URL structure:
- Pattern: `^hiring/([^/]+)-(interview-questions|job-description)/?$`
- Hub: `^hiring/?$`

### Security Features

- Nonce verification for all form submissions
- Capability checks (requires `manage_options`)
- File upload validation (MIME type, size, extension)
- Input sanitization and output escaping
- Prepared database queries

### Compatibility

- **WordPress Version**: 5.8 or higher
- **PHP Version**: 7.4 or higher
- **Database**: Uses WordPress post and post meta tables (no custom tables)

## Uninstallation

When you delete the plugin through WordPress admin:

1. All hiring pages are deleted
2. All meta data is removed
3. Hub page is deleted
4. Plugin options are removed
5. Rewrite rules are flushed

**Note**: Deactivation does NOT delete data. Only full uninstallation removes everything.

## Support

For issues or questions:
1. Check that you're using WordPress 5.8+ and PHP 7.4+
2. Verify CSV format matches the examples
3. Check WordPress debug log for errors

## Changelog

### Version 1.0.0
- Initial release
- Custom post type for hiring pages
- CSV bulk upload functionality
- Automated hub page generation
- Admin interface for managing pages
- Custom URL structure

## Developer Notes

### Hooks Available

The plugin uses standard WordPress hooks. You can extend functionality using:

```php
// After hiring page is created/updated
add_action('save_post_x0pa_hiring_page', 'your_function');

// Modify hub page content
add_filter('the_content', 'your_function');
```

### Accessing Meta Data

```php
// Get page type
$page_type = get_post_meta($post_id, '_x0pa_page_type', true);

// Get job title
$job_title = get_post_meta($post_id, '_x0pa_job_title', true);

// Get content JSON
$content = get_post_meta($post_id, '_x0pa_content_json', true);
$data = json_decode($content, true);
```

### Custom Queries

```php
// Get all interview questions pages
$args = array(
    'post_type' => 'x0pa_hiring_page',
    'meta_query' => array(
        array(
            'key' => '_x0pa_page_type',
            'value' => 'interview-questions',
        ),
    ),
);
$pages = get_posts($args);
```

## License

GPL v2 or later

## Credits

Developed by X0PA
