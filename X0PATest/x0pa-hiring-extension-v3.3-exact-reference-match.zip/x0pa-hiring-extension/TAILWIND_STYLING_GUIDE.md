# Tailwind CSS Styling Guide
## X0PA Hiring Extension Plugin

**Date:** November 17, 2025
**Version:** 1.0.0
**CDN:** https://cdn.tailwindcss.com?plugins=forms

---

## Table of Contents

1. [Overview](#overview)
2. [Color Palette](#color-palette)
3. [Layout Structure](#layout-structure)
4. [Component Classes](#component-classes)
5. [Mobile-First Responsive Design](#mobile-first-responsive-design)
6. [Implementation Notes](#implementation-notes)
7. [Code Examples](#code-examples)

---

## Overview

This plugin uses **Tailwind CSS via CDN** with a mobile-first approach. All styling is applied through utility classes and custom component classes defined in `/includes/assets/css/styles.php`.

### Key Principles:

- ✅ **Mobile-first**: Base styles work on 375px screens, then scale up
- ✅ **CDN-only**: No build process required
- ✅ **Semantic HTML**: Clean, accessible markup
- ✅ **Component-based**: Reusable class patterns
- ✅ **Performance**: Optimized for speed and accessibility

---

## Color Palette

Custom brand colors are defined in `/includes/config/tailwind-config.php`:

```php
colors: {
  'primary': '#173b8c',      // Main brand blue
  'dark': '#17141c',         // Text/headings
  'accent': '#f59e0a',       // CTA buttons (orange)
  'navy': '#172b69',         // Darker blue variant
  'gray': '#a3a1a8',         // Border/text gray
  'purple-dark': '#1a1238',  // Dark purple
  'blue-dark': '#171f54',    // Dark blue backgrounds
  'teal': '#61adb8',         // Teal accent
}
```

### Usage Examples:

```html
<!-- Primary blue background -->
<div class="bg-primary text-white">...</div>

<!-- Dark text -->
<h1 class="text-dark">...</h1>

<!-- Accent button -->
<button class="bg-accent hover:bg-opacity-90">...</button>

<!-- Gray border -->
<div class="border border-gray">...</div>
```

---

## Layout Structure

### 3-Column Responsive Grid

The main layout uses a responsive grid that adapts across devices:

```html
<div class="hiring">
  <!-- Hero section (full-width background) -->
  <div class="hiring__hero">...</div>

  <!-- 3-column layout -->
  <div class="hiring__layout">
    <!-- Left sidebar (TOC) - Hidden on mobile -->
    <aside class="hiring__layout-sidebar-left">...</aside>

    <!-- Main content -->
    <main class="hiring__layout-content">...</main>

    <!-- Right sidebar (Author/Resources) -->
    <aside class="hiring__layout-sidebar-right">...</aside>
  </div>
</div>
```

### Responsive Behavior:

| Screen Size | Layout |
|-------------|--------|
| Mobile (<640px) | Single column: Content → Right sidebar |
| Tablet (640-1024px) | 2 columns: Content + Right sidebar |
| Desktop (>1024px) | 3 columns: TOC + Content + Sidebar |

---

## Component Classes

### 1. Hero Section

```css
.hiring__hero
  ↳ Full viewport-width background (blue-dark)
  ↳ Responsive padding: py-12 (mobile) → py-16 (desktop)
  ↳ Uses negative margins to break out of container

.hiring__hero-wrapper
  ↳ Constrains content to max-w-7xl
  ↳ Flexbox: column (mobile) → row (desktop)

.hiring__hero-title
  ↳ text-3xl (mobile) → text-5xl (desktop)
  ↳ Bold, white text
  ↳ Leading-tight for readability

.hiring__hero-description
  ↳ text-base (mobile) → text-lg (desktop)
  ↳ Max-width: 2xl for readability
  ↳ Centered with mx-auto
```

**Example:**

```html
<div class="hiring__hero">
  <div class="hiring__hero-wrapper">
    <div class="hiring__hero-content">
      <div class="hiring__hero-tag">
        <span class="hiring__hero-tag-text">Interview Questions</span>
      </div>
      <h1 class="hiring__hero-title">Accountant Interview Questions</h1>
      <p class="hiring__hero-description">Expert-crafted questions to identify top talent.</p>
      <div class="hiring__meta">
        <span class="hiring__meta-item">Reading time: 5 min</span>
      </div>
    </div>
  </div>
</div>
```

---

### 2. Content Sections

```css
.content-section
  ↳ White background, rounded corners
  ↳ Vertical spacing between sections

.content-section__title
  ↳ text-lg (mobile) → text-xl (desktop)
  ↳ Border-bottom: 2px primary color
  ↳ Margin-bottom: 4-6

.content-section__body
  ↳ Flex column with gap-6 (mobile) → gap-8 (desktop)
```

**Example:**

```html
<section id="technical-accounting" class="content-section">
  <div class="content-section__title">Technical Accounting Knowledge</div>
  <div class="content-section__body">
    <!-- Question items go here -->
  </div>
</section>
```

---

### 3. Question/Answer Items

```css
.content-item
  ↳ Container for each question/answer pair

.content-item__title (h3)
  ↳ text-xl (mobile) → text-2xl (desktop)
  ↳ Bold, dark text
  ↳ IMPORTANT: Required for FAQ schema markup

.content-item__box
  ↳ White background with gray border
  ↳ Padding: p-3 (mobile) → p-4 (desktop)
  ↳ Rounded corners

.content-item__box-title (h4)
  ↳ text-xs (mobile) → text-sm (desktop)
  ↳ Semibold, navy color

.content-item__box-list (ul)
  ↳ Disc bullets, inside positioning
  ↳ Flex column with gap-1
  ↳ IMPORTANT: Required for FAQ schema markup
```

**Example:**

```html
<article class="content-item">
  <h3 class="content-item__title">
    Can you explain the difference between accrual and cash basis accounting?
  </h3>
  <div class="content-item__box">
    <h4 class="content-item__box-title">What to Listen For:</h4>
    <ul class="content-item__box-list">
      <li class="content-item__box-list-item">Clear understanding of timing differences</li>
      <li class="content-item__box-list-item">Knowledge of tax implications</li>
      <li class="content-item__box-list-item">Practical examples from experience</li>
    </ul>
  </div>
</article>
```

---

### 4. Jump Links Navigation (TOC)

```css
.jump-links
  ↳ Sticky on desktop (top-8)
  ↳ Border-right on desktop
  ↳ Mobile: Collapsible accordion
  ↳ Desktop: Always visible

.jump-links__toggle
  ↳ Mobile: Clickable header
  ↳ Desktop: Non-interactive (pointer-events-none)

.jump-links__list
  ↳ Hidden on mobile (accordion closed)
  ↳ Visible on desktop (lg:flex)

.jump-links__link
  ↳ text-xs (mobile) → text-sm (desktop)
  ↳ Gray text, primary on hover

.jump-links__link--active
  ↳ Blue background (bg-blue-50)
  ↳ Primary color, font-medium
```

**Example:**

```html
<nav class="jump-links">
  <button class="jump-links__toggle" aria-expanded="false">
    <h2 class="jump-links__title">On This Page</h2>
    <svg class="jump-links__toggle-icon"><!-- Chevron --></svg>
  </button>
  <ul class="jump-links__list">
    <li class="jump-links__item">
      <a href="#section1" class="jump-links__link jump-links__link--active">Section 1</a>
    </li>
    <li class="jump-links__item">
      <a href="#section2" class="jump-links__link">Section 2</a>
    </li>
  </ul>
</nav>
```

---

### 5. Sidebar Components

#### Author Card

```html
<div class="bg-white border border-gray rounded-lg p-3 flex items-start gap-4 shadow-sm mb-6">
  <img src="..." alt="Nina Suri" class="w-16 h-16 rounded-full flex-shrink-0 object-cover">
  <div class="flex-1">
    <div class="font-bold text-dark mb-1">Nina Alag Suri</div>
    <div class="text-sm text-gray mb-2">Founder and CEO</div>
    <a href="..." class="text-primary hover:text-navy">LinkedIn</a>
  </div>
</div>
```

#### Resources Sticky

```html
<div class="lg:sticky top-8 mt-6 z-10 flex flex-col gap-6">
  <div class="bg-white border border-gray rounded-lg p-6">
    <h3 class="text-lg font-bold text-dark mb-4">More Templates</h3>
    <ul class="flex flex-col gap-2 mb-4">
      <li class="text-sm text-gray hover:text-primary">
        <a href="#">Finance Manager Interview Questions</a>
      </li>
    </ul>
    <a href="/hiring/" class="text-primary hover:text-navy font-semibold text-sm">
      Browse All Templates →
    </a>
  </div>

  <!-- PDF Download Button (interview-questions only) -->
  <button id="pdf-download-btn-sidebar"
          class="bg-primary text-white px-4 py-2.5 rounded-lg font-semibold
                 transition-all duration-200 hover:bg-navy flex gap-2 cursor-pointer w-full">
    <span class="text-sm">Download Interview Questions PDF</span>
  </button>
</div>
```

---

### 6. CTA Components

#### Product Card (In-content CTA)

```html
<div class="bg-blue-dark py-8 sm:py-12 px-4 sm:px-8 rounded-lg">
  <div class="max-w-4xl mx-auto text-center">
    <h2 class="text-2xl sm:text-3xl font-bold text-white mb-4">
      Download Free Accountant Interview Questions
    </h2>
    <p class="text-white text-base sm:text-lg mb-6 leading-relaxed">
      Get expert-crafted questions designed specifically for accountant roles.
    </p>
    <div class="flex flex-col sm:flex-row gap-4 justify-center">
      <button id="pdf-download-btn"
              class="flex sm:inline-flex items-center justify-center gap-2
                     px-6 py-3 rounded-lg font-semibold
                     bg-accent text-white hover:bg-opacity-90 shadow-md cursor-pointer">
        <svg class="w-5 h-5"><!-- Download icon --></svg>
        <span>Download PDF</span>
      </button>
    </div>
  </div>
</div>
```

---

## Mobile-First Responsive Design

### Breakpoints

```css
/* Tailwind default breakpoints */
sm:   640px   /* Small tablets, large phones */
md:   768px   /* Tablets */
lg:   1024px  /* Desktop */
xl:   1280px  /* Large desktop */
2xl:  1536px  /* Extra large desktop */
```

### Design Approach

1. **Start with mobile** (base styles, no prefix)
2. **Add tablet** enhancements (sm:, md:)
3. **Add desktop** enhancements (lg:, xl:)

### Examples:

```html
<!-- Mobile: text-3xl, Desktop: text-5xl -->
<h1 class="text-3xl sm:text-4xl md:text-5xl">...</h1>

<!-- Mobile: p-4, Desktop: p-8 -->
<div class="p-4 sm:p-6 lg:p-8">...</div>

<!-- Mobile: hidden, Desktop: block -->
<aside class="hidden lg:block">...</aside>

<!-- Mobile: single column, Desktop: 3 columns -->
<div class="grid grid-cols-1 lg:grid-cols-[250px_1fr_260px]">...</div>
```

### Touch-Friendly Targets

All interactive elements maintain **minimum 44px tap targets** on mobile:

```css
@media (max-width: 768px) {
  button, a {
    min-height: 44px;
    min-width: 44px;
  }
}
```

---

## Implementation Notes

### 1. Including Tailwind in WordPress Templates

**In PHP template files:**

```php
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com?plugins=forms"></script>

  <!-- Custom Tailwind Config -->
  <?php include X0PA_HIRING_PLUGIN_DIR . 'includes/config/tailwind-config.php'; ?>

  <!-- Custom Component Styles -->
  <?php include X0PA_HIRING_PLUGIN_DIR . 'includes/assets/css/styles.php'; ?>
</head>
<body class="bg-white">
  <!-- Page content -->
</body>
</html>
```

### 2. PHP Dynamic Classes

Use PHP to conditionally apply classes:

```php
<div class="<?php echo $isActive ? 'bg-primary' : 'bg-gray'; ?>">
  <?php echo esc_html($content); ?>
</div>
```

### 3. Accessibility

- Use semantic HTML (`<nav>`, `<article>`, `<aside>`)
- Include ARIA attributes for interactive elements
- Maintain WCAG AA color contrast (all colors meet this standard)
- Ensure keyboard navigation works (focus states included)

### 4. Performance

- Tailwind CDN is cached by browsers
- Component classes are scoped to avoid bloat
- No custom CSS files beyond component definitions
- Minimal JavaScript required

---

## Code Examples

### Full Interview Questions Page Structure

```html
<div class="hiring">
  <!-- Hero -->
  <div class="hiring__hero">
    <div class="hiring__hero-wrapper">
      <div class="hiring__hero-content">
        <h1 class="hiring__hero-title">Accountant Interview Questions</h1>
        <p class="hiring__hero-description">Expert-crafted questions...</p>
        <div class="hiring__meta">
          <span class="hiring__meta-item">Reading time: 5 min</span>
          <span class="hiring__meta-divider">•</span>
          <span class="hiring__meta-item">Updated: Nov 2025</span>
        </div>
      </div>
    </div>
  </div>

  <!-- 3-column layout -->
  <div class="hiring__layout">
    <!-- Left sidebar: TOC -->
    <aside class="hiring__layout-sidebar-left">
      <nav class="jump-links">
        <!-- TOC content -->
      </nav>
    </aside>

    <!-- Main content -->
    <main class="hiring__layout-content">
      <!-- Questions overview -->
      <section id="overview" class="content-section">
        <!-- Overview content -->
      </section>

      <!-- Question sections -->
      <section id="technical" class="content-section">
        <div class="content-section__title">Technical Questions</div>
        <div class="content-section__body">
          <article class="content-item">
            <h3 class="content-item__title">Question 1?</h3>
            <div class="content-item__box">
              <h4 class="content-item__box-title">What to Listen For:</h4>
              <ul class="content-item__box-list">
                <li class="content-item__box-list-item">Point 1</li>
                <li class="content-item__box-list-item">Point 2</li>
              </ul>
            </div>
          </article>
        </div>
      </section>
    </main>

    <!-- Right sidebar: Author + Resources -->
    <aside class="hiring__layout-sidebar-right">
      <!-- Author card -->
      <div class="bg-white border border-gray rounded-lg p-3">...</div>

      <!-- Resources sticky -->
      <div class="lg:sticky top-8 mt-6">...</div>
    </aside>
  </div>
</div>
```

### Full Job Description Page Structure

```html
<div class="hiring">
  <!-- Hero (same structure as interview-questions) -->
  <div class="hiring__hero">...</div>

  <!-- 3-column layout -->
  <div class="hiring__layout">
    <!-- Left sidebar: TOC -->
    <aside class="hiring__layout-sidebar-left">...</aside>

    <!-- Main content -->
    <main class="hiring__layout-content">
      <!-- Job description sections -->
      <section id="objectives" class="content-section">
        <div class="content-section__title">Objectives of this Role</div>
        <div class="content-section__body">
          <article class="content-item">
            <div class="job-description-section">
              <div class="job-description-section__content">
                <ul class="content-item__box-list">
                  <li class="content-item__box-list-item">Objective 1</li>
                  <li class="content-item__box-list-item">Objective 2</li>
                </ul>
              </div>
            </div>
          </article>
        </div>
      </section>

      <section id="responsibilities" class="content-section">
        <div class="content-section__title">Key Responsibilities</div>
        <div class="content-section__body">
          <article class="content-item">
            <div class="job-description-section">
              <div class="job-description-section__content">
                • Process accounts payable and receivable
                • Maintain general ledger entries
                • Prepare basic financial reports
              </div>
            </div>
          </article>
        </div>
      </section>
    </main>

    <!-- Right sidebar (NO PDF button for job-description) -->
    <aside class="hiring__layout-sidebar-right">...</aside>
  </div>
</div>
```

---

## Testing Checklist

### Mobile (375px - 640px)

- [ ] Hero text is readable (not too large)
- [ ] Content sections stack vertically
- [ ] TOC is hidden
- [ ] Right sidebar appears below content
- [ ] All buttons are at least 44px tall
- [ ] Text is at least 16px base size

### Tablet (640px - 1024px)

- [ ] Hero scales appropriately
- [ ] Content remains single column or 2-column
- [ ] TOC may be hidden or sidebar
- [ ] Padding increases from mobile

### Desktop (1024px+)

- [ ] 3-column layout displays correctly
- [ ] TOC sticky positioning works
- [ ] Resources sidebar sticky positioning works
- [ ] Hover states work on links/buttons
- [ ] Focus states visible for keyboard navigation

### Cross-Browser

- [ ] Chrome/Edge (Chromium)
- [ ] Firefox
- [ ] Safari (desktop + iOS)

---

## FAQ Schema Compliance

The following elements are **required** for proper FAQ schema markup:

1. **Question heading** (`<h3 class="content-item__title">`)
   - Must be unique per page
   - Must contain the full question text

2. **Answer container** (`<div class="content-item__box">`)
   - Contains the answer content

3. **Answer list** (`<ul class="content-item__box-list">`)
   - List items are the answer points
   - Must use semantic `<ul>` and `<li>` tags

**Example for Schema:**

```html
<article class="content-item" itemscope itemtype="https://schema.org/Question">
  <h3 class="content-item__title" itemprop="name">
    What is accrual accounting?
  </h3>
  <div class="content-item__box" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
    <div itemprop="text">
      <h4 class="content-item__box-title">What to Listen For:</h4>
      <ul class="content-item__box-list">
        <li class="content-item__box-list-item">Understanding of timing differences</li>
        <li class="content-item__box-list-item">Knowledge of revenue recognition</li>
      </ul>
    </div>
  </div>
</article>
```

---

## Conclusion

This Tailwind CSS styling system provides:

✅ **Mobile-first responsive design**
✅ **Consistent brand colors**
✅ **Reusable component classes**
✅ **Accessible, semantic markup**
✅ **Performance-optimized CDN delivery**
✅ **Easy maintenance (no build process)**

All templates follow these patterns to ensure consistency across the X0PA Hiring Extension plugin.

---

**Questions or Issues?**

Refer to:
- `/includes/config/tailwind-config.php` - Color configuration
- `/includes/assets/css/styles.php` - Component class definitions
- Reference files in `/X0PA-Web-Dev/` - Working examples

**Last Updated:** November 17, 2025
