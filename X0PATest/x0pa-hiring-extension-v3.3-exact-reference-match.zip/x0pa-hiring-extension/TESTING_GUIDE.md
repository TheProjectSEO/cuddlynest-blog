# X0PA Hiring Extension - Testing Guide

Comprehensive testing procedures for all PHP logic components.

---

## Table of Contents

1. [Unit Testing](#unit-testing)
2. [Integration Testing](#integration-testing)
3. [Schema Validation](#schema-validation)
4. [Performance Testing](#performance-testing)
5. [Manual Testing Checklist](#manual-testing-checklist)

---

## Unit Testing

### Schema Generators

#### Test: WebPage Schema Generation

```php
<?php
/**
 * Test WebPage Schema
 */
function test_webpage_schema() {
    // Create test post
    $post_id = wp_insert_post(array(
        'post_title' => 'Test Software Engineer Interview Questions',
        'post_type' => 'x0pa_hiring_page',
        'post_status' => 'publish'
    ));

    // Add metadata
    update_post_meta($post_id, '_x0pa_job_title', 'Software Engineer');
    update_post_meta($post_id, '_x0pa_page_type', 'interview-questions');
    update_post_meta($post_id, '_x0pa_last_updated', '2024-01-15');

    $post = get_post($post_id);
    $schema = X0PA_WebPage_Schema::generate($post);

    // Assertions
    assert(!empty($schema), 'Schema should not be empty');

    $decoded = json_decode($schema, true);

    assert(isset($decoded['@context']), 'Should have @context');
    assert($decoded['@context'] === 'https://schema.org', 'Context should be schema.org');
    assert($decoded['@type'] === 'WebPage', 'Type should be WebPage');
    assert(isset($decoded['name']), 'Should have name');
    assert(isset($decoded['breadcrumb']), 'Should have breadcrumb');

    // Cleanup
    wp_delete_post($post_id, true);

    echo "✅ WebPage Schema test passed\n";
}
```

#### Test: FAQ Schema Extraction

```php
<?php
/**
 * Test FAQ Schema
 */
function test_faq_schema() {
    $html_content = '
    <div class="content-item">
        <h3 class="content-item__title">What is your experience with Python?</h3>
        <div class="content-item__box">
            <ul class="content-item__box-list">
                <li class="content-item__box-list-item">Discuss years of experience</li>
                <li class="content-item__box-list-item">Mention specific projects</li>
                <li class="content-item__box-list-item">Highlight frameworks used</li>
            </ul>
        </div>
    </div>
    <div class="content-item">
        <h3 class="content-item__title">How do you handle code reviews?</h3>
        <div class="content-item__box">
            <ul class="content-item__box-list">
                <li class="content-item__box-list-item">Be constructive</li>
                <li class="content-item__box-list-item">Focus on code quality</li>
            </ul>
        </div>
    </div>
    ';

    $schema = X0PA_FAQ_Schema::generate($html_content, 2);

    assert(!empty($schema), 'FAQ schema should not be empty');

    $decoded = json_decode($schema, true);

    assert($decoded['@type'] === 'FAQPage', 'Type should be FAQPage');
    assert(count($decoded['mainEntity']) === 2, 'Should have 2 questions');
    assert(isset($decoded['mainEntity'][0]['name']), 'Question should have name');
    assert(isset($decoded['mainEntity'][0]['acceptedAnswer']), 'Question should have answer');

    echo "✅ FAQ Schema test passed\n";
}
```

#### Test: Author Schema

```php
<?php
/**
 * Test Author Schema
 */
function test_author_schema() {
    // Test full schema
    $full_schema = X0PA_Author_Schema::generate(false);

    assert(isset($full_schema['@context']), 'Full schema should have context');
    assert($full_schema['name'] === 'Nina Alag Suri', 'Should have correct name');
    assert(isset($full_schema['worksFor']), 'Should have worksFor');

    // Test reference schema (no context)
    $ref_schema = X0PA_Author_Schema::generate(true);

    assert(!isset($ref_schema['@context']), 'Reference should not have context');
    assert(isset($ref_schema['name']), 'Reference should have name');

    echo "✅ Author Schema test passed\n";
}
```

### Internal Linking

#### Test: Similarity Calculation

```php
<?php
/**
 * Test Similarity Algorithm
 */
function test_similarity_algorithm() {
    // Create test pages
    $pages = array(
        array('title' => 'Senior Software Engineer', 'type' => 'interview-questions'),
        array('title' => 'Software Engineer', 'type' => 'interview-questions'),
        array('title' => 'Frontend Developer', 'type' => 'interview-questions'),
        array('title' => 'Data Scientist', 'type' => 'interview-questions'),
    );

    $post_ids = array();

    foreach ($pages as $page) {
        $post_id = wp_insert_post(array(
            'post_title' => $page['title'],
            'post_type' => 'x0pa_hiring_page',
            'post_status' => 'publish'
        ));

        update_post_meta($post_id, '_x0pa_job_title', $page['title']);
        update_post_meta($post_id, '_x0pa_page_type', $page['type']);

        $post_ids[] = $post_id;
    }

    // Test: "Software Engineer" should be most similar to "Senior Software Engineer"
    $related = X0PA_Internal_Linking::get_related_pages(
        'Software Engineer',
        'interview-questions',
        $post_ids[1], // Current page (Software Engineer)
        3
    );

    assert(!empty($related), 'Should return related pages');
    assert($related[0]['job_title'] === 'Senior Software Engineer', 'Most similar should be Senior Software Engineer');

    // Verify current page is excluded
    foreach ($related as $page) {
        assert($page['post_id'] !== $post_ids[1], 'Current page should be excluded');
    }

    // Cleanup
    foreach ($post_ids as $id) {
        wp_delete_post($id, true);
    }

    echo "✅ Similarity algorithm test passed\n";
}
```

#### Test: Cache Functionality

```php
<?php
/**
 * Test Internal Linking Cache
 */
function test_internal_linking_cache() {
    // Create test page
    $post_id = wp_insert_post(array(
        'post_title' => 'Test Engineer',
        'post_type' => 'x0pa_hiring_page',
        'post_status' => 'publish'
    ));

    update_post_meta($post_id, '_x0pa_job_title', 'Test Engineer');
    update_post_meta($post_id, '_x0pa_page_type', 'interview-questions');

    // Clear cache
    X0PA_Internal_Linking::clear_all_caches();

    // First call (should query DB)
    $start = microtime(true);
    $related1 = X0PA_Internal_Linking::get_related_pages('Test Engineer', 'interview-questions', $post_id, 4);
    $time1 = microtime(true) - $start;

    // Second call (should use cache)
    $start = microtime(true);
    $related2 = X0PA_Internal_Linking::get_related_pages('Test Engineer', 'interview-questions', $post_id, 4);
    $time2 = microtime(true) - $start;

    assert($time2 < $time1, 'Cached call should be faster');
    assert($related1 === $related2, 'Cached result should match');

    // Cleanup
    wp_delete_post($post_id, true);

    echo "✅ Cache functionality test passed (First: {$time1}s, Cached: {$time2}s)\n";
}
```

### Content Generators

#### Test: TOC Generation

```php
<?php
/**
 * Test TOC Generator
 */
function test_toc_generator() {
    $content_json = json_encode(array(
        array(
            'section_id' => 'technical-questions',
            'section_title' => 'Technical Questions',
            'questions' => array(
                array('question' => 'Question 1'),
                array('question' => 'Question 2'),
                array('question' => 'Question 3')
            )
        ),
        array(
            'section_id' => 'behavioral-questions',
            'section_title' => 'Behavioral Questions',
            'questions' => array(
                array('question' => 'Question 1'),
                array('question' => 'Question 2')
            )
        )
    ));

    $toc = X0PA_TOC_Generator::generate_from_content($content_json);

    assert(count($toc) === 2, 'Should have 2 sections');
    assert($toc[0]['id'] === 'technical-questions', 'First section should be technical');
    assert($toc[0]['count'] === 3, 'First section should have 3 questions');
    assert($toc[1]['count'] === 2, 'Second section should have 2 questions');

    echo "✅ TOC Generator test passed\n";
}
```

#### Test: Reading Time Calculation

```php
<?php
/**
 * Test Reading Time
 */
function test_reading_time() {
    // 200 words = 1 minute
    $content_200 = str_repeat('word ', 200);
    $time1 = X0PA_SEO_Meta::calculate_reading_time($content_200);
    assert($time1 === 1, '200 words should be 1 minute');

    // 500 words = 3 minutes (at 200 wpm)
    $content_500 = str_repeat('word ', 500);
    $time2 = X0PA_SEO_Meta::calculate_reading_time($content_500);
    assert($time2 === 3, '500 words should be 3 minutes');

    // 1000 words = 5 minutes
    $content_1000 = str_repeat('word ', 1000);
    $time3 = X0PA_SEO_Meta::calculate_reading_time($content_1000);
    assert($time3 === 5, '1000 words should be 5 minutes');

    echo "✅ Reading time calculation test passed\n";
}
```

#### Test: SEO Meta Generation

```php
<?php
/**
 * Test SEO Meta Generator
 */
function test_seo_meta() {
    $post_id = wp_insert_post(array(
        'post_title' => 'Software Engineer Interview Questions',
        'post_type' => 'x0pa_hiring_page',
        'post_status' => 'publish'
    ));

    update_post_meta($post_id, '_x0pa_job_title', 'Software Engineer');
    update_post_meta($post_id, '_x0pa_page_type', 'interview-questions');

    $post = get_post($post_id);
    $content = str_repeat('word ', 400); // 2 min read

    $meta = X0PA_SEO_Meta::generate($post, $content);

    assert(isset($meta['title']), 'Should have title');
    assert(isset($meta['description']), 'Should have description');
    assert(isset($meta['og:title']), 'Should have OG title');
    assert($meta['reading_time'] === 2, 'Reading time should be 2 minutes');
    assert($meta['word_count'] === 400, 'Word count should be 400');

    wp_delete_post($post_id, true);

    echo "✅ SEO Meta generation test passed\n";
}
```

### Hub Page

#### Test: Hub Page Creation

```php
<?php
/**
 * Test Hub Page Creation
 */
function test_hub_page_creation() {
    // Delete existing hub page if any
    $existing = get_page_by_path('hiring');
    if ($existing) {
        wp_delete_post($existing->ID, true);
    }

    // Create hub page
    $page_id = X0PA_Hub_Page::create_hub_page();

    assert(is_numeric($page_id), 'Should return page ID');

    $page = get_post($page_id);

    assert($page->post_type === 'page', 'Should be a page');
    assert($page->post_name === 'hiring', 'Should have correct slug');
    assert($page->post_status === 'publish', 'Should be published');

    $template = get_post_meta($page_id, '_wp_page_template', true);
    assert($template === 'x0pa-hub-page.php', 'Should have correct template');

    echo "✅ Hub page creation test passed\n";
}
```

#### Test: Grouped Pages

```php
<?php
/**
 * Test Grouped Pages Logic
 */
function test_grouped_pages() {
    // Create test pages
    $pages = array(
        array('title' => 'Software Engineer', 'type' => 'interview-questions'),
        array('title' => 'Software Engineer', 'type' => 'job-description'),
        array('title' => 'Data Scientist', 'type' => 'interview-questions'),
    );

    $post_ids = array();

    foreach ($pages as $page) {
        $post_id = wp_insert_post(array(
            'post_title' => $page['title'] . ' ' . $page['type'],
            'post_type' => 'x0pa_hiring_page',
            'post_status' => 'publish'
        ));

        update_post_meta($post_id, '_x0pa_job_title', $page['title']);
        update_post_meta($post_id, '_x0pa_page_type', $page['type']);
        update_post_meta($post_id, '_x0pa_last_updated', date('Y-m-d H:i:s'));

        $post_ids[] = $post_id;
    }

    // Get grouped pages
    X0PA_Hub_Page::clear_cache();
    $grouped = X0PA_Hub_Page::get_grouped_pages(false);

    assert(isset($grouped['Software Engineer']), 'Should have Software Engineer');
    assert(isset($grouped['Data Scientist']), 'Should have Data Scientist');

    $se_data = $grouped['Software Engineer'];
    assert(isset($se_data['pages']['interview-questions']), 'Should have interview questions');
    assert(isset($se_data['pages']['job-description']), 'Should have job description');

    // Test statistics
    $stats = X0PA_Hub_Page::get_statistics();
    assert($stats['total_job_titles'] >= 2, 'Should have at least 2 job titles');
    assert($stats['complete_sets'] >= 1, 'Should have at least 1 complete set');

    // Cleanup
    foreach ($post_ids as $id) {
        wp_delete_post($id, true);
    }

    echo "✅ Grouped pages test passed\n";
}
```

---

## Integration Testing

### End-to-End Page Rendering

```php
<?php
/**
 * Test Complete Page Rendering
 */
function test_complete_page_rendering() {
    // Create test page
    $post_id = wp_insert_post(array(
        'post_title' => 'Full Stack Developer Interview Questions',
        'post_type' => 'x0pa_hiring_page',
        'post_status' => 'publish'
    ));

    $content_json = json_encode(array(
        array(
            'section_id' => 'frontend',
            'section_title' => 'Frontend Questions',
            'questions' => array(
                array('question' => 'What is React?'),
                array('question' => 'Explain hooks')
            )
        )
    ));

    update_post_meta($post_id, '_x0pa_job_title', 'Full Stack Developer');
    update_post_meta($post_id, '_x0pa_page_type', 'interview-questions');
    update_post_meta($post_id, '_x0pa_content_json', $content_json);
    update_post_meta($post_id, '_x0pa_last_updated', date('Y-m-d H:i:s'));

    $post = get_post($post_id);

    // Test all components
    $seo_meta = X0PA_SEO_Meta::generate($post, $content_json);
    assert(!empty($seo_meta), 'SEO meta should be generated');

    $hero = X0PA_Hero_Generator::generate($post, $seo_meta);
    assert(strpos($hero, 'Full Stack Developer') !== false, 'Hero should contain job title');

    $toc = X0PA_TOC_Generator::generate_from_content($content_json);
    assert(!empty($toc), 'TOC should be generated');

    $overview = X0PA_Interview_Overview::generate($content_json, 'Full Stack Developer');
    assert(strpos($overview, 'Frontend Questions') !== false, 'Overview should contain categories');

    $webpage_schema = X0PA_WebPage_Schema::generate($post);
    assert(!empty($webpage_schema), 'WebPage schema should be generated');

    $faq_schema = X0PA_FAQ_Schema::generate($content_json);
    // FAQ schema might be empty if < 3 questions, that's OK

    wp_delete_post($post_id, true);

    echo "✅ Complete page rendering test passed\n";
}
```

---

## Schema Validation

### Validate with Google Rich Results Test

```php
<?php
/**
 * Output schemas for Google validation
 */
function output_schemas_for_validation($post_id) {
    $post = get_post($post_id);
    $content_json = get_post_meta($post_id, '_x0pa_content_json', true);

    echo "=== WebPage Schema ===\n";
    echo X0PA_WebPage_Schema::generate($post);
    echo "\n\n";

    echo "=== Author Schema ===\n";
    echo X0PA_Author_Schema::get_json_ld(false);
    echo "\n\n";

    echo "=== FAQ Schema ===\n";
    echo X0PA_FAQ_Schema::generate($content_json, 3);
    echo "\n\n";

    echo "Copy each schema above and test at:\n";
    echo "https://search.google.com/test/rich-results\n";
}
```

**Manual Steps:**
1. Run the function for a test post
2. Copy each JSON-LD output
3. Paste into Google Rich Results Test
4. Verify no errors or warnings

---

## Performance Testing

### Benchmark All Components

```php
<?php
/**
 * Performance Benchmarks
 */
function benchmark_all_components() {
    $iterations = 100;

    echo "Running performance benchmarks ({$iterations} iterations)...\n\n";

    // Create test data
    $post_id = wp_insert_post(array(
        'post_title' => 'Test Post',
        'post_type' => 'x0pa_hiring_page',
        'post_status' => 'publish'
    ));

    update_post_meta($post_id, '_x0pa_job_title', 'Software Engineer');
    update_post_meta($post_id, '_x0pa_page_type', 'interview-questions');
    update_post_meta($post_id, '_x0pa_last_updated', date('Y-m-d H:i:s'));

    $content_json = json_encode(array(
        array(
            'section_id' => 'test',
            'section_title' => 'Test',
            'questions' => array_fill(0, 20, array('question' => 'Test question'))
        )
    ));

    update_post_meta($post_id, '_x0pa_content_json', $content_json);

    $post = get_post($post_id);

    // Benchmark functions
    $benchmarks = array(
        'WebPage Schema' => function() use ($post) {
            X0PA_WebPage_Schema::generate($post);
        },
        'Author Schema' => function() {
            X0PA_Author_Schema::generate(false);
        },
        'FAQ Schema' => function() use ($content_json) {
            X0PA_FAQ_Schema::generate($content_json, 3);
        },
        'SEO Meta' => function() use ($post, $content_json) {
            X0PA_SEO_Meta::generate($post, $content_json);
        },
        'TOC Generation' => function() use ($content_json) {
            X0PA_TOC_Generator::generate_from_content($content_json);
        },
        'Hero Generation' => function() use ($post) {
            X0PA_Hero_Generator::generate($post, array());
        },
        'Internal Linking (cached)' => function() use ($post_id) {
            X0PA_Internal_Linking::get_related_pages('Software Engineer', 'interview-questions', $post_id, 4);
        }
    );

    foreach ($benchmarks as $name => $callback) {
        $start = microtime(true);

        for ($i = 0; $i < $iterations; $i++) {
            $callback();
        }

        $time = microtime(true) - $start;
        $avg = ($time / $iterations) * 1000; // Convert to ms

        $status = $avg < 50 ? '✅' : ($avg < 100 ? '⚠️' : '❌');

        echo "{$status} {$name}: " . number_format($avg, 2) . "ms average\n";
    }

    wp_delete_post($post_id, true);

    echo "\nTarget: < 50ms per operation\n";
}
```

---

## Manual Testing Checklist

### Schema Testing

- [ ] WebPage schema validates in Google Rich Results Test
- [ ] Author schema shows correct Nina Alag Suri information
- [ ] FAQ schema generates for pages with 3+ questions
- [ ] FAQ schema does NOT generate for pages with < 3 questions
- [ ] Breadcrumb schema shows correct hierarchy
- [ ] All schemas are valid JSON
- [ ] No duplicate schemas on page

### Internal Linking Testing

- [ ] Related pages show for each page type
- [ ] Current page is NEVER in related pages list
- [ ] Most similar pages appear first (check with obvious cases)
- [ ] Cache works (second load is faster)
- [ ] Complementary pages link between page types
- [ ] Links are valid and not broken
- [ ] "Software Engineer" links to "Senior Software Engineer" with high score

### Content Generator Testing

- [ ] Hero section displays job title correctly
- [ ] Hero shows correct page type badge
- [ ] Reading time displays accurately
- [ ] TOC navigation works (smooth scroll)
- [ ] TOC highlights active section on scroll
- [ ] Mobile TOC dropdown works
- [ ] Interview overview shows correct question count
- [ ] Category statistics are accurate

### Hub Page Testing

- [ ] Hub page accessible at /hiring/
- [ ] All job titles are listed
- [ ] Job titles link to correct pages
- [ ] Search functionality filters results
- [ ] Statistics show correct numbers
- [ ] Page sorts alphabetically
- [ ] Both page types show for each job title
- [ ] Last updated dates are accurate

### Performance Testing

- [ ] Page load time < 2 seconds
- [ ] Schema generation < 50ms
- [ ] Internal linking (cached) < 10ms
- [ ] Internal linking (uncached) < 500ms for 100 pages
- [ ] TOC generation < 100ms
- [ ] Hub page render < 300ms
- [ ] No memory leaks or excessive memory usage

### Mobile Testing

- [ ] Hero section responsive
- [ ] TOC dropdown works on mobile
- [ ] Related pages display correctly
- [ ] Hub page search works on mobile
- [ ] Touch interactions smooth
- [ ] No horizontal scroll

### Error Handling Testing

- [ ] Handles null post gracefully
- [ ] Handles empty content gracefully
- [ ] Handles invalid JSON gracefully
- [ ] Handles missing meta data gracefully
- [ ] No PHP warnings or notices
- [ ] Error logs are clean

---

## Running All Tests

```php
<?php
/**
 * Run all unit tests
 */
function run_all_tests() {
    echo "=== X0PA Hiring Extension Test Suite ===\n\n";

    $tests = array(
        'test_webpage_schema',
        'test_faq_schema',
        'test_author_schema',
        'test_similarity_algorithm',
        'test_internal_linking_cache',
        'test_toc_generator',
        'test_reading_time',
        'test_seo_meta',
        'test_hub_page_creation',
        'test_grouped_pages',
        'test_complete_page_rendering'
    );

    $passed = 0;
    $failed = 0;

    foreach ($tests as $test) {
        try {
            $test();
            $passed++;
        } catch (Exception $e) {
            echo "❌ {$test} FAILED: " . $e->getMessage() . "\n";
            $failed++;
        }
    }

    echo "\n=== Test Summary ===\n";
    echo "Passed: {$passed}\n";
    echo "Failed: {$failed}\n";

    if ($failed === 0) {
        echo "\n✅ All tests passed!\n";
    }
}
```

---

## Continuous Testing

Add to your CI/CD pipeline:

```bash
# Run PHP unit tests
wp eval-file tests/unit-tests.php

# Validate schemas
wp eval "output_schemas_for_validation(123);" | node validate-schema.js

# Performance benchmarks
wp eval-file tests/performance-tests.php
```

---

## Next Steps

1. Run unit tests for all components
2. Validate schemas with Google tools
3. Performance benchmark with real data
4. Manual testing on staging environment
5. Fix any issues found
6. Repeat testing after fixes
7. Deploy to production

Good luck with testing! 🚀
