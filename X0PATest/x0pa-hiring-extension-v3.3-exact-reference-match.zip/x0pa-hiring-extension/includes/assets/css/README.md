# CSS Assets - Tailwind Component Styles
## X0PA Hiring Extension Plugin

This directory contains the Tailwind CSS component stylesheet for the plugin.

---

## File: styles.php

**Purpose:** Component class definitions using Tailwind's `@apply` directive

**Format:** PHP file containing `<style type="text/tailwindcss">` block

**Usage:** Include in template `<head>` after Tailwind CDN and config

```php
<!-- In your template file -->
<head>
  <!-- 1. Tailwind CDN -->
  <script src="https://cdn.tailwindcss.com?plugins=forms"></script>

  <!-- 2. Custom Config -->
  <?php include X0PA_HIRING_PLUGIN_DIR . 'includes/config/tailwind-config.php'; ?>

  <!-- 3. Component Styles (this file) -->
  <?php include X0PA_HIRING_PLUGIN_DIR . 'includes/assets/css/styles.php'; ?>
</head>
```

---

## Component Classes Defined

### Layout Components
- `.hiring` - Main container (max-w-7xl)
- `.hiring__layout` - 3-column responsive grid
- `.hiring__layout-sidebar-left` - TOC sidebar
- `.hiring__layout-content` - Main content area
- `.hiring__layout-sidebar-right` - Author/Resources sidebar

### Hero Section
- `.hiring__hero` - Full-width background
- `.hiring__hero-wrapper` - Content container
- `.hiring__hero-content` - Hero content area
- `.hiring__hero-tag` - Badge/tag
- `.hiring__hero-tag-text` - Tag text
- `.hiring__hero-title` - Hero heading (responsive)
- `.hiring__hero-description` - Hero description
- `.hiring__meta` - Metadata (reading time, date)
- `.hiring__meta-item` - Individual meta item
- `.hiring__meta-link` - Meta link
- `.hiring__meta-divider` - Divider between items

### Content Sections
- `.content-section` - Section wrapper
- `.content-section__title` - Section heading
- `.content-section__body` - Section content

### Question/Answer Items
- `.content-item` - Question container
- `.content-item__title` - Question heading (h3)
- `.content-item__box` - Answer box
- `.content-item__box-title` - "What to Listen For" heading
- `.content-item__box-list` - Answer list (ul)
- `.content-item__box-list-item` - Answer list item (li)

### Job Description
- `.job-description-section` - Template code box
- `.job-description-section__content` - Template content

### Interview Questions List
- `.interview-questions-list` - Ordered question list
- `.interview-questions-list-item` - Question list item
- `.interview-questions-list__title` - List section title

### Navigation (TOC)
- `.jump-links` - TOC container (sticky on desktop)
- `.jump-links__toggle` - Mobile accordion toggle
- `.jump-links__title` - TOC title
- `.jump-links__toggle-icon` - Chevron icon
- `.jump-links__list` - Link list
- `.jump-links__list--expanded` - Expanded state (mobile)
- `.jump-links__item` - List item
- `.jump-links__link` - TOC link
- `.jump-links__link--active` - Active link state

### Utility Classes
- `.highlighted-text` - Primary colored, semibold text

---

## Mobile-First Responsive Design

All classes use mobile-first approach:

```css
/* Mobile base styles */
.hiring__hero-title {
  @apply text-3xl font-bold text-white mb-6 leading-tight;
}

/* Tablet and up */
@apply sm:text-4xl;

/* Desktop and up */
@apply md:text-5xl;
```

**Breakpoints:**
- Mobile: < 640px (base styles)
- SM: 640px+ (sm:)
- MD: 768px+ (md:)
- LG: 1024px+ (lg:)
- XL: 1280px+ (xl:)

---

## BEM Naming Convention

All classes follow BEM (Block Element Modifier):

```
.block { }              /* Component */
.block__element { }     /* Child element */
.block--modifier { }    /* State/variant */
```

**Example:**
```html
<nav class="jump-links">                        <!-- Block -->
  <a href="#" class="jump-links__link">...</a>  <!-- Element -->
  <a href="#" class="jump-links__link jump-links__link--active">...</a>  <!-- Modifier -->
</nav>
```

---

## Global Styles

### Smooth Scroll
```css
html {
  scroll-behavior: smooth;
}
```

### Touch Targets (Mobile)
```css
@media (max-width: 768px) {
  button, a {
    min-height: 44px;
    min-width: 44px;
  }
}
```

---

## Documentation

For complete documentation, see:
- `/TAILWIND_STYLING_GUIDE.md` - Comprehensive guide
- `/QUICK_START_STYLING.md` - Quick reference
- `/RESPONSIVE_DESIGN_NOTES.md` - Responsive patterns

---

## Modifying Styles

### Adding New Component Classes

1. Open `styles.php`
2. Add your class within the `@layer components` block
3. Use Tailwind's `@apply` directive
4. Follow BEM naming convention
5. Use mobile-first responsive approach

**Example:**

```css
/* In styles.php */
@layer components {
  .my-new-component {
    @apply bg-white rounded-lg p-4 border border-gray;
  }

  .my-new-component__title {
    @apply text-lg sm:text-xl font-bold text-dark mb-4;
  }

  .my-new-component__body {
    @apply text-base sm:text-lg text-gray;
  }
}
```

### Testing Changes

1. Include the file in your template
2. Apply the class to HTML elements
3. Test on mobile (375px) first
4. Test responsive breakpoints (640px, 768px, 1024px)
5. Verify in Chrome, Firefox, Safari

---

## Best Practices

✅ **DO:**
- Use mobile-first approach (base → sm: → md: → lg:)
- Follow BEM naming convention
- Use Tailwind utility classes via `@apply`
- Test responsively before committing
- Document new component classes

❌ **DON'T:**
- Add inline styles in HTML (use component classes)
- Create redundant utility classes (use Tailwind directly)
- Skip mobile testing
- Use non-semantic class names
- Forget to include file in template `<head>`

---

## Color Reference

Custom colors defined in `/includes/config/tailwind-config.php`:

```
primary:      #173b8c
dark:         #17141c
accent:       #f59e0a
navy:         #172b69
gray:         #a3a1a8
blue-dark:    #171f54
teal:         #61adb8
purple-dark:  #1a1238
```

Usage in `@apply`:
```css
.my-class {
  @apply bg-primary text-white;      /* Blue background, white text */
  @apply hover:bg-navy;              /* Darker blue on hover */
}
```

---

## File Structure

```
includes/
└── assets/
    └── css/
        ├── styles.php       ✅ Component styles (this file)
        └── README.md        ✅ Documentation (this file)
```

---

## Dependencies

This file requires:
1. **Tailwind CSS CDN** - Must be loaded first
2. **tailwind-config.php** - Must be loaded before this file

Both must be included in template `<head>` before `styles.php`.

---

## Performance

- **File Size:** ~400 lines (~15KB)
- **Load Time:** Negligible (inline in HTML)
- **Caching:** Cached with page HTML
- **Impact:** Minimal (component classes only, no redundant CSS)

---

## Maintenance

When updating:
1. Edit `styles.php`
2. Test changes across all breakpoints
3. Update documentation if adding new classes
4. Commit changes to version control

---

**Last Updated:** November 17, 2025
**Tailwind Version:** Latest (via CDN)
**Plugin Version:** 1.0.0
