# X0PA Hiring Extension - Template Files

## Overview
Semantic, well-structured HTML templates for the X0PA Hiring Extension WordPress plugin. These templates follow accessibility best practices, use proper heading hierarchy, and implement mobile-first responsive design with Tailwind CSS.

## Template Structure

### Main Page Templates

#### 1. template-interview-questions.php
**Purpose:** Interview questions pages for specific job titles
**URL Pattern:** `/hiring-resources/{job-title}-interview-questions/`

**Structure:**
- Hero section with job title, reading time, last updated
- Left sidebar: Table of contents / jump links
- Main content: Question sections with "What to Listen For" criteria
- Right sidebar: Author bio, newsletter, sticky resources
- Footer CTA: How X0PA helps

**Key Sections:**
- `#questions-overview` - Auto-generated overview card
- Dynamic question sections (e.g., `#technical-skills`, `#communication`)
- Cross-link to job description

#### 2. template-job-description.php
**Purpose:** Job description templates for specific job titles
**URL Pattern:** `/hiring-resources/{job-title}-job-description/`

**Structure:**
- Hero section with job title, reading time, last updated
- Left sidebar: Table of contents / jump links
- Main content: Job description sections
- Right sidebar: Author bio, newsletter, sticky resources
- Footer CTA: How X0PA helps

**Key Sections:**
- `#objectives` - Role objectives
- `#responsibilities` - Key responsibilities
- `#required-skills` - Required qualifications
- `#preferred-skills` - Preferred qualifications
- `#what-{job-title}-does` - Role explanation
- `#skills-to-look-for` - Hiring criteria
- Cross-link to interview questions

#### 3. template-hub-page.php
**Purpose:** Central directory listing all hiring resources
**URL Pattern:** `/hiring-resources/`

**Features:**
- Search functionality (filters by job title)
- Category filter dropdown
- Responsive grid of job title cards
- Each card links to interview questions and job description
- Results count and "no results" state
- Footer CTA section

## Partial Templates

### Sidebar Components

#### sidebar-author.php
**Author bio card featuring:**
- Profile image
- Name and title (Nina Alag Suri, VP of Product)
- Professional bio
- LinkedIn link
- Expertise tags

#### sidebar-newsletter.php
**Newsletter signup form with:**
- Email input field
- HubSpot integration
- Success/error states
- Privacy policy link
- Benefits list

#### sidebar-resources-sticky.php
**Sticky sidebar section with:**
- Related internal links (dynamically populated)
- CTA to request demo
- Quick stats (50% faster hiring, 85% better matches, 10K+ companies)
- Sticky scroll behavior script

### CTA Components

#### cta-cross-link.php
**Cross-linking between resources:**
- From interview questions → job description
- From job description → interview questions
- Links to hub page for more resources
- Conditional display based on `$page_type`

#### footer-cta.php
**Full-width footer CTA section:**
- Main headline and subtitle
- 4-column features grid
- Stats bar (companies, time to hire, quality matches, satisfaction)
- Primary and secondary CTA buttons
- Trust badges area

#### pdf-download-modal.php
**HubSpot-gated PDF download modal:**
- Form fields: First name, last name, email, company, job title
- Consent checkbox
- Benefits list
- Success state
- Keyboard accessible (ESC to close)
- Click backdrop to close
- Analytics tracking

## HTML Standards & Best Practices

### Semantic Structure
- Uses proper HTML5 semantic elements (`<header>`, `<main>`, `<article>`, `<section>`, `<aside>`, `<nav>`)
- Proper heading hierarchy (h1 → h2 → h3 → h4)
- Meaningful element nesting

### Accessibility (WCAG 2.1 AA)
- ARIA labels and roles where appropriate
- `aria-hidden` for decorative icons
- `aria-live` regions for dynamic content
- Screen reader only text with `.sr-only`
- Keyboard navigation support
- Focus management in modals
- Proper form labels and error states

### BEM Class Naming Convention
```css
.block { }
.block__element { }
.block--modifier { }
```

**Examples:**
- `.hiring__layout`
- `.content-section__title`
- `.sidebar-card--author`
- `.btn--primary`

### Mobile-First Responsive Design
- Base styles for mobile (320px+)
- Tailwind responsive prefixes: `md:`, `lg:`
- Flexbox and Grid layouts
- Proper viewport meta tag
- Touch-friendly tap targets (44px minimum)

## PHP Integration Points

### Required Variables
Templates expect these variables to be set:

**For Interview Questions:**
```php
$job_title = "Accountant";
$hero_config = [...];
$seo_config = [...];
$question_sections = [...];
$body_content = "..."; // Generated content
$sections = [...]; // TOC sections
$cross_link_url = "..."; // URL to job description
```

**For Job Description:**
```php
$job_title = "Accountant";
$hero_config = [...];
$seo_config = [...];
$job_data = [...];
$body_content = "..."; // Generated content
$sections = [...]; // TOC sections
$cross_link_url = "..."; // URL to interview questions
```

**For Hub Page:**
```php
$job_titles = [
    'Accountant' => [
        'category' => 'accounting',
        'interview-questions' => '/hiring-resources/accountant-interview-questions/',
        'job-description' => '/hiring-resources/accountant-job-description/',
    ],
    // ... more job titles
];
```

### Required Generator Functions
Templates call these functions from `/includes/generators/`:

- `generate_seo_meta($seo_config, $body_content)`
- `generate_hero_section($hero_config, $body_content)`
- `generate_toc_from_content($body_content)`
- `render_jump_links($sections, $first_section_id)`
- `generate_interview_questions_section($content, $job_title)` (interview questions only)

### File Includes
Templates include these files:
- `../config/tailwind-config.php` - Tailwind custom configuration
- `../assets/css/styles.php` - Custom CSS styles
- `../tracking/tracking-codes-head.php` - Analytics (head)
- `../tracking/tracking-codes-body-start.php` - Analytics (body start)
- `../tracking/tracking-codes-body-end.php` - Analytics (body end)
- `../components/cta__product-card-interview-questions.php`
- `../components/cta__product-card-job-description.php`

### JavaScript Files
- `../assets/js/hiring-script.js` - Main functionality (scroll spy, jump links)
- `../assets/js/hubspot-newsletter.js` - Newsletter form handling
- `../assets/js/hubspot-pdf-gate.js` - PDF download form handling

## Next Steps

1. **Styling Agent** - Apply Tailwind CSS classes to match reference files exactly
2. **PHP Agent** - Create generator functions and data structures
3. **Integration** - Wire up WordPress plugin hooks and shortcodes
4. **Testing** - Validate HTML, test accessibility, check mobile responsiveness

## File Paths Reference

```
x0pa-hiring-extension/
└── includes/
    └── templates/
        ├── template-interview-questions.php
        ├── template-job-description.php
        ├── template-hub-page.php
        ├── partials/
        │   ├── sidebar-author.php
        │   ├── sidebar-newsletter.php
        │   ├── sidebar-resources-sticky.php
        │   ├── cta-cross-link.php
        │   ├── footer-cta.php
        │   └── pdf-download-modal.php
        └── README.md (this file)
```

## Notes

- All templates use PHP's `plugin_dir_path(__FILE__)` and `plugin_dir_url(__FILE__)` for correct file paths
- PRESERVE comments mark sections that should not be modified by optimization tools
- All user-generated content is escaped with `esc_html()`, `esc_attr()`, `esc_url()`
- Forms include proper validation and error handling
- Modals trap focus and handle keyboard events
- All external links use `rel="noopener noreferrer"` for security
